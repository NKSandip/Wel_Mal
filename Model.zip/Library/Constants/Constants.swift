//
//  Constants.swift
//  OnDemandApp
//  Created by Sourabh Bhardwaj on 01/04/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation

let APPDELEGATE  = UIApplication.shared.delegate as! AppDelegate
let FEED_JOB_REQUEST = 0;
let NEW_JOB_REQUEST = 1; // applied job list
let ONGOING_JOB_REQUEST = 2;
let COMPLETED_JOB_REQUEST = 3;

enum NavType : Int {
    case kNavTypeOther
    case kNavTypeBidder
}

struct Constants {
    
    static let DEFAULT_SCREEN_RATIO: CGFloat = 375.0
    
    static let PASSWORD_REGEX: String = "^(?=.*[A-Z])(?=.*[a-z])(?=.*[0-9]).{8,20}$"
    static let NAME_REGEX: String = "^[a-zA-Z0-9]{1,15}$"
    static let SIGNUP_MESSAGE : String = "Please sign up to continue."
    static let cornerColorBlack = UIColor().colorWithRedValue(255, greenValue: 255, blueValue: 255, alpha: 0.1).cgColor
    static let cornerColor = UIColor().colorWithRedValue(30, greenValue: 157, blueValue: 205, alpha: 0.5).cgColor
    static let cornerColorGreen = UIColor().colorWithRedValue(39, greenValue: 193, blueValue: 221, alpha: 1).cgColor
    static let cornerColorDullBlack = UIColor().colorWithRedValue(50, greenValue: 50, blueValue: 50, alpha: 1).cgColor
    static let kViewTypeReportAbuse = 1
    static let kViewTypeContactUs = 2
    static let kViewTypeDecline = 3
    static let kViewTypeRequestProfileVerified = 10
    
    static let PAGE_TYPE_CHOOSE_CATEGORY = 1
    static let PAGE_TYPE_CHOOSE_TAGS = 2
    
    static let PROGRESS_TYPE_ONGOING = 1
    static let PROGRESS_TYPE_APPLIED = 2
    static let PROGRESS_TYPE_HISTORY = 3
    static let PROGRESS_TYPE_DISPUTED = 4
    static let PROGRESS_TYPE_NEW = 4
    static let PROGRESS_TYPE_COMPLETED = 5
    static let NOTIFICATION_UNREAD_COUNT = NSNotification.Name(rawValue: "unreadCount")
    static let NOTIFICATION_UPDATE_TAG = NSNotification.Name(rawValue: "updateTags")
    static let NOTIFICATION_LOGOUT = NSNotification.Name(rawValue: "logout")
    
    
    
    // MARK: Tokens
    struct Tokens {
        static let MIX_PANNEL_TOKEN: String = "15107c3acf51538c6aac6da5e43101ac"
        static let FLURRY_APP_ID: String = "RX82NVGNGCFV7XY4X7VB"
        static let GOOGLE_ANALYTICS_APP_ID: String = "UA-76023878-1"
        static let GOOGLE_MAPS_API_KEY: String = "AIzaSyBLkUwEm7ZpcGeXsSeJV6XAEHqtIgO_02A"
        static let STRIPE_API_KEY = "pk_test_dTP1NdrF5pTZt3VxNY2zEIen"
        static let APPSEE_API_KEY = "00bc2cfce00e4fb8bd88034ac403cf0a"
        static var twitterConsumerKey : String = "Mk4DruYnvAefLad7kvINnxv2R"
        static var twitterSecretKey : String = "dqRpiyMUIQQKWcEy6I0ULhdZyOpNgMwg59U2V422npm5buAWdq"
    }
    
    
    static let BASE_URL = Constants.apiBaseURL()
    
    static let kShowBoardingForFirstTime = "show_boarding_for_first_time"
    
    static func apiBaseURL() -> String {
        return ConfigurationManager.sharedManager().APIEndPoint()
    }
    
    static let SCREEN_RATIO: CGFloat = UIScreen.main.bounds.width/375
    
    struct Urls {
        static let termsAndConditons = Constants.Urls.getURL("pages/seeker-terms")
        static let termsAndConditonsSeeker = Constants.Urls.getURL("pages/seeker-terms")
        static let termsAndConditonsProvider = Constants.Urls.getURL("pages/provider-terms")
        static let privacyPolicy = Constants.Urls.getURL("pages/seeker-terms")
        static let aboutUs = Constants.Urls.getURL("user/aboutUs")
        
        static func getURL(_ methodName: String) -> String {
            return Constants.apiBaseURL() + "/" + methodName
        }
    }
    
    // MARK: APIServiceMethods
    struct APIServiceMethods {
        
        static let socialLoginGoogleProvider = Constants.APIServiceMethods.apiURL("provider/google-register")
        static let socialLoginGoogleSeeker = Constants.APIServiceMethods.apiURL("user/google-register")
        
        static let socialLoginLinkedInProvider = Constants.APIServiceMethods.apiURL("provider/linkedin-register")
        static let socialLoginLinkedInSeeker = Constants.APIServiceMethods.apiURL("user/linkedin-register")
        
        static let socialLoginTwitterProvider = Constants.APIServiceMethods.apiURL("provider/twitter-register")
        static let socialLoginTwitterSeeker = Constants.APIServiceMethods.apiURL("user/twitter-register")
        static var loginAPI = Constants.APIServiceMethods.apiURL("user/login")
        static let socialLoginAPI = Constants.APIServiceMethods.apiURL("user/socialLogin")
        static var socialLoginFB = Constants.APIServiceMethods.apiURL(UserManager.sharedManager().userTypeString() + "/" + "fb-register")
        static let otpLoginAPI = Constants.APIServiceMethods.apiURL("otp/send-otp")
        static let otpLoginVerifyAPI = Constants.APIServiceMethods.apiURL("otp/verify-otp")
        static let loginWithPhoneAPI = Constants.APIServiceMethods.apiURL("loginWithPhone")
        static let logoutAPI = Constants.APIServiceMethods.apiURL("user/logout")
        static let deleteAPI = Constants.APIServiceMethods.apiURL("user/user-detail")
        static var sigupAPI = Constants.APIServiceMethods.apiURL(UserManager.sharedManager().userTypeString() + "/" + "register")
        static var checkEmailAPI = Constants.APIServiceMethods.apiURL(UserManager.sharedManager().userTypeString() + "/" + "check-email")
        static let imageUploadAPI = Constants.APIServiceMethods.apiURL("user/uploadFile")
        static let sendOtpAPI = Constants.APIServiceMethods.apiURL("getOtp")
        static let verifyOtpAPI = Constants.APIServiceMethods.apiURL("otpVerification")
        static let resetPasswordAPI = Constants.APIServiceMethods.apiURL("user/forgot-password")
        static let changePasswordAPI = Constants.APIServiceMethods.apiURL("user/change-password")
        static let bankDetailAPI = Constants.APIServiceMethods.apiURL("user/update-bank-detail")
        static let updateProfileAPI = Constants.APIServiceMethods.apiURL("user/update-profile")
        static let userDetailAPI = Constants.APIServiceMethods.apiURL("user/user-details")
        static let updateProfileImage = Constants.APIServiceMethods.apiURL("user/update-image")
        static let uploadDocImage = Constants.APIServiceMethods.apiURL("service/upload-service-image")
        static let addProfileImage = Constants.APIServiceMethods.apiURL("user/add-image")
        static let getPopularCategory = Constants.APIServiceMethods.apiURL("category/popular-list")
        
        static let getCategory = Constants.APIServiceMethods.apiURL("user/categories-tags")
        static let getServices = Constants.APIServiceMethods.apiURL("service/list")
        static let getMySavedServices = Constants.APIServiceMethods.apiURL("service/provider-service")
        static let saveCategory = Constants.APIServiceMethods.apiURL("category/save")
        static let addService = Constants.APIServiceMethods.apiURL("service/add-services")
        static let saveService = Constants.APIServiceMethods.apiURL("service/add")
        
        static let getNearByProviders = Constants.APIServiceMethods.apiURL("service/near-by-providers")
        
        static let getSingleTypeList = Constants.APIServiceMethods.apiURL("service/list")
        
        static let bookServiceOfProvider = Constants.APIServiceMethods.apiURL("service/book")
        static var getMyJobsAPI = Constants.APIServiceMethods.apiURL("job/" + UserManager.sharedManager().userTypeString() + "-list/")
        static var getHistoryJobsAPI = Constants.APIServiceMethods.apiURL("job/" + UserManager.sharedManager().userTypeString() + "-job-history/")
        static let getJobSeekersAPI = Constants.APIServiceMethods.apiURL("provider/popular-seeker/")
        
        static let getOpenJobsAPI = Constants.APIServiceMethods.apiURL("job/user-job-details/")
        static let acceptJob = Constants.APIServiceMethods.apiURL("job/accept-job")
        static let notificationList = Constants.APIServiceMethods.apiURL("notification/list/")
        static let cancelJob = Constants.APIServiceMethods.apiURL("job/cancel-job")
        static let readNotification = Constants.APIServiceMethods.apiURL("notification/mark-read")
        static let unreadNotificationCount = Constants.APIServiceMethods.apiURL("notification/unread-count")
        static let cancelMyBid = Constants.APIServiceMethods.apiURL("bid/cancel-my-bid")
        static let completeJob = Constants.APIServiceMethods.apiURL("job/complete-job")
        static let getServiceTypes = Constants.APIServiceMethods.apiURL("service/user-list")
        static let paymentToken = Constants.APIServiceMethods.apiURL("payment/make-payment")///feedback/save-feedback
        static let createAccountOnStripe = "https://" + "api.stripe.com/v1/accounts"
        static let addBankToken = Constants.APIServiceMethods.apiURL("payment/add-bank-token")
        static let getCountryList = Constants.APIServiceMethods.apiURL("payment/country-list")
        static let getGulfCountryList = Constants.APIServiceMethods.apiURL("user/countries-cities")
        static let getDocumentList = Constants.APIServiceMethods.apiURL("job/job-documents/")
        static let getJobBidDocumentList = Constants.APIServiceMethods.apiURL("job/job-bid-documents/")
        static let sendFeedback = Constants.APIServiceMethods.apiURL("feedback/save-feedback")
        static let getFeedbackList = Constants.APIServiceMethods.apiURL("feedback/provider-pending-feedback")
        static let sendHireProfileInfo = Constants.APIServiceMethods.apiURL("user/update-profile")
        static let sendWorkProfileInfo = Constants.APIServiceMethods.apiURL("provider/update-profile")
        static let postJob = Constants.APIServiceMethods.apiURL("service/add-service")
        static let updateJob = Constants.APIServiceMethods.apiURL("service/update-service")
        static let acceptBid = Constants.APIServiceMethods.apiURL("service/accept-bid")
        static let hireCompleteJob = Constants.APIServiceMethods.apiURL("job/complete-job")
        static let deleteJob = Constants.APIServiceMethods.apiURL("job/delete")
        static let notificationSetting = Constants.APIServiceMethods.apiURL("user/notification-setting")
        static let bidJob = Constants.APIServiceMethods.apiURL("bid/post-bid")
        static let adminBankDetail = Constants.APIServiceMethods.apiURL("user/admin-bank-details")
        static var contactUsAPI = Constants.APIServiceMethods.apiURL("user/contact-us-email")
        static var profileReqestAPI = Constants.APIServiceMethods.apiURL("user/add-verification-request")
        static var getCheckOutReqestAPI = Constants.APIServiceMethods.apiURL("user/checkout")
         static var getPaymentStatusReqestAPI = Constants.APIServiceMethods.apiURL("user/paymentstatus")
        
        static var reportUsAPI = Constants.APIServiceMethods.apiURL("job/abuse")
        static let getChatHistoryAPI = Constants.APIServiceMethods.apiURL("chat/list")
        static let uploadChatDataAPI = Constants.APIServiceMethods.apiURL("chat/post")
        static let jobDetailAPI = Constants.APIServiceMethods.apiURL("job/current-job-detail")
        static let chatDetailAPI = Constants.APIServiceMethods.apiURL("chat/details")
        
        static func apiURL(_ methodName: String) -> String {
            let baseUrl = "http://52.57.124.52/e3mal/e3mal-php/public/api/v1"// Local
            //"https://api.e3mal.co/api/v1"// Production
            //ConfigurationManager.sharedManager().APIEndPoint()
            return baseUrl + "/" + methodName
        }
    }
    
    struct CellIdentifiers {
        static let kPostJobFirstCell = "PostJobFirstCell"
        static let kPostJobSecondCell = "PostJobSecondCell"
        static let kPostJobThirdCell = "PostJobThirdCell"
        static let kPostJobFourthCell = "PostJobFourthCell"
        static let kPostJobFifthCell = "PostJobFifthCell"
        static let kPostJobSixthCell = "PostJobSixthCell"
        static let kPostJobSeventhCell = "PostJobSeventhCell"
        static let kUploadDocumentCell = "UploadImageCell"
    }
    
    struct TableViewRowsCount {
        static let kPostJob = 14
    }
    
    struct LocalisedString {
        static let  kPostJobVCTitle = "POST A PROJECT"
        static let  kPostJobTableHeader = "POST YOUR REQUIREMENT"
        static let  kJobTitle = "Job Title"
        static let  kJobTitlePlaceholder = "Enter Job Title"
        static let  kType = "Type"
        static let  kPysicalType = "Physical"
        static let  kVirtualType = "Virtual"
        static let  kCountry = "Country"
        static let  kCountryPlaceholder = "Select Country"
        static let  kLocation = "Location"
        static let  kLocationPlaceholder = "Select Location"
        static let  kPriceRange = "Price Range"
        static let  kStartDate = "Start date"
        static let  kStartDatePlaceholder = "Select Start Date"
        static let  kEndDate = "End Date"
        static let  kEndDatePlaceholder = "Select End Date"
        static let  kDescription = "Description"
        static let  kBiddingEndDate = "Bidding End Date"
        static let  kBiddingEndDatePlaceholder = "Select Date"
        static let  kTags = "Tags"
        static let  kTagsPlaceholder = "Add Tags"
        static let  kCategories = "Category"
        static let  kCategoriesPlaceholder = "Add Category"
        static let  kDocuments = "Documents"
        static let  kUpload = "UPLOAD"
        static let  kDownload = "Download"
        static let  kViewDocuments = "View Documents"
        static let  kAddTitle = "Add Title"
        static let  kAddURL = "Add URL"
        static let  kUploadDocument = "UPLOAD DOCUMENT"
        static let  kResetPassword = "RESET PASSWORD"
        static let  kSubmitDetail = "SUBMIT DETAIL"
    }
    
    struct StoryboardIdentifiers {
        static let kUploadVC = "APUploadVC"
    }
}
