//
//  BaseViewController.swift
//  OnDemandApp
//  Created by Arvind Singh on 20/05/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation
import UIKit

open class BaseViewController: UIViewController {
    
    fileprivate var _tapGesture: UITapGestureRecognizer?
    
    // MARK: View Lifecycle
    override open func viewDidLoad() {
        super.viewDidLoad()
        UIApplication.shared.statusBarStyle = .default
        self.setNeedsStatusBarAppearanceUpdate()
    }
    
    override open func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillShow(_:)), name: NSNotification.Name.UIKeyboardWillShow, object: nil);
        NotificationCenter.default.addObserver(self, selector: #selector(self.keyboardWillHide(_:)), name: NSNotification.Name.UIKeyboardWillHide, object: nil);
    }
    
    override open func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        
        self.removeTapGesture()
        self.dismissKeyboard()
        
        NotificationCenter.default.removeObserver(self);
    }
    
    override open func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    
    // MARK: Private Methods
    fileprivate func addTapGesture() -> Void {
        _tapGesture = UITapGestureRecognizer(target: self, action: #selector(self.handleGesture(_:)))
        self.view.addGestureRecognizer(_tapGesture!)
    }
    
    func removeTapGesture() -> Void {
        if let tapGesture = _tapGesture {
            self.view.removeGestureRecognizer(tapGesture)
            _tapGesture = nil
        }
    }
    
    fileprivate func dismissKeyboard() -> Void {
        self.view.endEditing(true)
    }
    
    
    // MARK: Control Actions
    @IBAction func backButtonPressed(_ sender: UIButton) {
        _ = self.navigationController?.popViewController(animated: true)
    }
    
    func chatTestAction(jobBidMemberObj:JobBidMember) {
        
        let chatView = ChatViewController()
        chatView.jobBidMember = jobBidMemberObj
        let chatNavigationController = UINavigationController(rootViewController: chatView)
        present(chatNavigationController, animated: true, completion: nil)
 
        
    }
    @IBAction func logoutButtonPressed(_ sender: UIButton) {
        
        //self.chatTestAction(incomingUserId: "55")
        logout()
        
    }
    
    func logout() {
        
        let logOut: String = Localization("Logout")
        let cancel: String = Localization("Cancel")
        let loggingOut: String = Localization("Logging Out")
        let pleaseWait: String = Localization("please wait")
        let alertController = UIAlertController(title: nil, message: nil, preferredStyle: UIAlertControllerStyle.actionSheet)
        alertController.restorationIdentifier = "LogoutMenuContainer"

        alertController.addAction(UIAlertAction(title: logOut , style: UIAlertActionStyle.destructive, handler: { (action) -> Void in

            // Handle Logout
            // show loader
             self.view.showLoader(mainTitle: loggingOut, subTitle: pleaseWait)
            UserManager.sharedManager().performLogout({ (success, error) -> (Void) in
                
                
                
                // hide loader
                DispatchQueue.main.async {
                    
                    self.view.hideLoader()
                    
                    // perform clean up
                    UserManager.sharedManager().deleteActiveUser()
                    APGoogleManager.sharedManager().logout()
                  AppDelegate.presentRootViewController(false, rootViewIdentifier: .toShowLoginScreen)
                }
                
                
            })
        }))
        alertController.addAction(UIAlertAction(title: cancel, style: UIAlertActionStyle.cancel, handler: nil))

        self.present(alertController, animated: true, completion: nil)
    }
    
    // MARK: Gesture Actions
    func handleGesture(_ sender: UITapGestureRecognizer) -> Void {
        self.dismissKeyboard()
    }
    
    // MARK: Keyboard Notification Observers
    func keyboardWillShow(_ sender: Foundation.Notification) {
        self.addTapGesture()
    }
    
    func keyboardWillHide(_ sender: Foundation.Notification) {
        self.removeTapGesture()
    }
    
    
}

extension UIViewController{

    func setTabBarVisible(visible:Bool, animated:Bool) {
        
        if self.tabBarController == nil {
            return
        }
        
        //* This cannot be called before viewDidLayoutSubviews(), because the frame is not set before this time
        
        // bail if the current state matches the desired state
        
        let tabBarController = self.tabBarController as! APTabBarViewController
        
        tabBarController.imageView?.isHidden = !visible
        
//        for view in UITabBar.appearance().subviews {
//            if view.tag == 12345 {
//                view.isHidden = visible
//            }
//        }
        
        
        if (tabBarIsVisible() == visible) { return }
        
        // get a frame calculation ready
        let frame = self.tabBarController?.tabBar.frame
        let height = frame?.size.height
        let offsetY = (visible ? -height! : height)
        
        // zero duration means no animation
        let duration:TimeInterval = (animated ? 0.3 : 0.0)
        
        //  animate the tabBar
        if frame != nil {
            UIView.animate(withDuration: duration) {
                self.tabBarController?.tabBar.frame = frame!.offsetBy(dx: 0, dy: offsetY!)
                return
            }
        }
    }
    
    func tabBarIsVisible() ->Bool {
        return (self.tabBarController?.tabBar.frame.origin.y)! < self.view.frame.maxY
    }

}
