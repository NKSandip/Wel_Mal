//
//  UILabel+Additions.swift
//  OnDemandApp
//  Created by Geetika Gupta on 01/04/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation
import UIKit
// MARK: - UILabel Extension
extension UILabel {
    
    /**
     Override method of awake from nib to change font size as per aspect ratio.
     */
    override open func awakeFromNib() {
        
        super.awakeFromNib()
        
        if let font = self.font {
            
            let screenRatio = (UIScreen.main.bounds.size.width / Constants.DEFAULT_SCREEN_RATIO)
            let fontSize = font.pointSize * screenRatio
            
            self.font = UIFont(name: font.fontName, size: fontSize)!
        }
    }
    
    /**
     method to provide spacing between characters.
     */
    
    func addTextSpacing(spacing: CGFloat){
        let attributedString = NSMutableAttributedString(string: self.text!)
        attributedString.addAttribute(NSKernAttributeName, value: spacing, range: NSRange(location: 0, length: self.text!.characters.count))
        self.attributedText = attributedString
    }
    
    func addLocalization(){
        
        self.text = Localization(self.text!)
        if Localisator.sharedInstance.currentLanguage == "ar" {
            self.font = UIFont(name: "Geeza Pro", size: (self.font?.pointSize)!)
        }
        
    }
    
    func addLocalizationBold(){
        
        self.text = Localization(self.text!)
        if Localisator.sharedInstance.currentLanguage == "ar" {
            self.font = UIFont(name: "GeezaPro-Bold", size: (self.font?.pointSize)!)
        }
        
    }
}
