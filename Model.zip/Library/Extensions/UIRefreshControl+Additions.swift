//
//  UIRefreshControl+Additions.swift
//  OnDemandApp
//
//  Created by Shwetabh Singh on 14/10/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation

extension UIRefreshControl
{
    // add Refresh Control
    class func getRefreshControl(_ viewController:UIViewController) -> UIRefreshControl{
        var refreshControl : UIRefreshControl!
        refreshControl = UIRefreshControl()
        refreshControl.backgroundColor = UIColor.white
        refreshControl.tintColor = UIColor.black
        refreshControl.addTarget(viewController, action:Selector(("refreshView")) , for: UIControlEvents.valueChanged)
        return refreshControl
    }
}
