//
//  UIStoryboard+Additions.swift
//  OnDemandApp
//  Created by Pawan Joshi on 31/03/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation
import UIKit

// MARK: - UIStoryboard Extension
extension UIStoryboard {
    
    /**
     Convenience Initializers to initialize storyboard.
     
     - parameter storyboard: String of storyboard name
     - parameter bundle:     NSBundle object
     
     - returns: A Storyboard object
     */
    convenience init(storyboard: String, bundle: Bundle? = nil) {
        self.init(name: storyboard, bundle: bundle)
    }
    
    
    /**
     Initiate view controller with view controller name.
     
     - returns: A UIView controller object
     */
    func instantiateViewController<T: UIViewController>() -> T {
        var fullName: String = NSStringFromClass(T.self)
        if let range = fullName.range(of: ".", options: .backwards) {
            fullName = fullName.substring(from: range.upperBound)
        }
        
        guard let viewController = self.instantiateViewController(withIdentifier: fullName) as? T else {
            fatalError("Couldn't instantiate view controller with identifier \(fullName) ")
        }
        
        return viewController
    }
    
    class func dashboardStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "Dashboard", bundle: nil)
    }
    class func seekerDashboardStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "SeekerDashboard", bundle: nil)
    }
    class func paymentStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "Payment", bundle: nil)
    }
    class func mainStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "Main", bundle: nil)
    }
    class func categoryStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "Category", bundle: nil)
    }
    class func settingsStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "Settings", bundle: nil)
    }
    
    class func tabbarControllerStoryboard() -> UIStoryboard {
        return UIStoryboard(name: "TabbarController", bundle: nil)
    }
    
    class func sendReportVC() -> SendReportVC? {
        return dashboardStoryboard().instantiateViewController(withIdentifier: "SendReportVC") as? SendReportVC
    }
    

    class func settingsVC() -> SettingsVC? {
        return settingsStoryboard().instantiateViewController(withIdentifier: "SettingsVC") as? SettingsVC
    }

    class func jobProgressVC() -> JobProgressVC? {
        return dashboardStoryboard().instantiateViewController(withIdentifier: "JobProgressVC") as? JobProgressVC

    }
    
    class func jobProgressAppliedVC() -> JobProgressAppliedVC? {
        return dashboardStoryboard().instantiateViewController(withIdentifier: "JobProgressAppliedVC") as? JobProgressAppliedVC
    }
    
    class func jobProgressOnGoingVC() -> JobProgressOnGoingVC? {
        return dashboardStoryboard().instantiateViewController(withIdentifier: "JobProgressOnGoingVC") as? JobProgressOnGoingVC
    }
    
    class func jobProgressHistoryVC() -> JobProgressHistoryVC? {
        return dashboardStoryboard().instantiateViewController(withIdentifier: "JobProgressHistoryVC") as? JobProgressHistoryVC
    }
    

    class func jobProgressDetailVC() -> JobProgressDetailVC? {
        return dashboardStoryboard().instantiateViewController(withIdentifier: "JobProgressDetailVC") as? JobProgressDetailVC
    }
    

    class func changePasswordVC() -> APChangePasswordViewController? {
        return settingsStoryboard().instantiateViewController(withIdentifier: "ChangePasswordVC") as? APChangePasswordViewController
    }
    
    class func bankDetailVC() -> APBankDetailVC? {
        return settingsStoryboard().instantiateViewController(withIdentifier: "BankDetailVC") as? APBankDetailVC
    }
    
    class func editProfileVC() -> APEditProfileVC? {
        return settingsStoryboard().instantiateViewController(withIdentifier: "EditProfileVC") as? APEditProfileVC
    }
    
    class func hireJobProgressVC() -> HireJobProgressVC? {
        return tabbarControllerStoryboard().instantiateViewController(withIdentifier: "HireJobProgressVC") as? HireJobProgressVC
        
    }
    
    class func hireJobProgressNewVC() -> HireJobProgressNewVC? {
        return tabbarControllerStoryboard().instantiateViewController(withIdentifier: "HireJobProgressNewVC") as? HireJobProgressNewVC
        
    }
    
    class func hireJobProgressOnGoingVC() -> HireJobProgressOnGoingVC? {
        return tabbarControllerStoryboard().instantiateViewController(withIdentifier: "HireJobProgressOnGoingVC") as? HireJobProgressOnGoingVC
        
    }
    
    class func hireJobProgressCompletedVC() -> HireJobProgressCompletedVC? {
        return tabbarControllerStoryboard().instantiateViewController(withIdentifier: "HireJobProgressCompletedVC") as? HireJobProgressCompletedVC
        
    }
    
    class func notificationsVC() -> APNotificationsVC? {
        return paymentStoryboard().instantiateViewController(withIdentifier: "APNotificationsVC") as? APNotificationsVC
        
    }
    
    class func tutorialVC() -> WLCTutorialVC {
        return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: "WLCTutorialVC") as! WLCTutorialVC
    }
    
    class func signUpVC() -> SignUpVC {
        return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: "SignUpVC") as! SignUpVC
    }
    
    class func  APLoginViewController() -> APLoginViewController {
        return UIStoryboard.mainStoryboard().instantiateViewController(withIdentifier: "APLoginViewController") as! APLoginViewController
    }

}
