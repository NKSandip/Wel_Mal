//
//  UITableViewCell+Additions.swift
//  E3malApp
//
//  Created by Rishav Tomar on 15/12/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import UIKit

extension UITableViewCell {
    


}
