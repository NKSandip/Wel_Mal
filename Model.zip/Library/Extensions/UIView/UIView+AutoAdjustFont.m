//
//  UIView+AutoAdjustFont.m
//  2Stones
//
//  Created by Hemant Sharma on 05/12/15.
//  Copyright © 2015 2Stones. All rights reserved.
//


#define kExcludedTag 999999
#define kFontMultiplier (IS_IPHONE_6 || IS_IPHONE_6P ? 1.1 : 1.0)
//#define kFontMultiplier 1

#import "UIView+AutoAdjustFont.h"

@implementation UIView (AutoAdjustFont)

- (void)adjustFontSizeAccordingToScreenSize {
    for (UIView *vw in [self allSubViews]) {
        if (vw.tag != kExcludedTag) {
            if ([vw isKindOfClass:[UILabel class]]) {
                [self adjustSizeOfLabel:(UILabel*)vw];
            } else if ([vw isKindOfClass:[UIButton class]]) {
                [self adjustSizeOfButton:(UIButton*)vw];
            } else if ([vw isKindOfClass:[UITextField class]]) {
                [self adjustSizeOfTextField:(UITextField*)vw];
            } else if ([vw isKindOfClass:[UITextView class]]) {
                [self adjustSizeOfTextView:(UITextView*)vw];
            }
        }
    }
}

- (void)adjustSizeOfLabel:(UILabel*)lbl {
    UIFont *currrentFont = lbl.font;
    CGFloat currentFontPointSize = currrentFont.pointSize;
    CGFloat newFontPointSize = currentFontPointSize * MAX(kFontMultiplier, 1);
    UIFont *newFont = [UIFont fontWithName:currrentFont.fontName size:newFontPointSize];
    if ([lbl respondsToSelector:@selector(setFont:)]) {
        [lbl setFont:newFont];
    }
}

- (void)adjustSizeOfButton:(UIButton*)btn {
    UIFont *currrentFont = btn.titleLabel.font;
    CGFloat currentFontPointSize = currrentFont.pointSize;
    CGFloat newFontPointSize = currentFontPointSize * MAX(kFontMultiplier, 1);
    UIFont *newFont = [UIFont fontWithName:currrentFont.fontName size:newFontPointSize];
    if ([btn.titleLabel respondsToSelector:@selector(setFont:)]) {
        [btn.titleLabel setFont:newFont];
    }
}

- (void)adjustSizeOfTextField:(UITextField*)txtFld {
    UIFont *currrentFont = txtFld.font;
    CGFloat currentFontPointSize = currrentFont.pointSize;
    CGFloat newFontPointSize = currentFontPointSize * MAX(kFontMultiplier, 1);
    UIFont *newFont = [UIFont fontWithName:currrentFont.fontName size:newFontPointSize];
    if ([txtFld respondsToSelector:@selector(setFont:)]) {
        [txtFld setFont:newFont];
    }
}

- (void)adjustSizeOfTextView:(UITextView*)txtVw {
    UIFont *currrentFont = txtVw.font;
    CGFloat currentFontPointSize = currrentFont.pointSize;
    CGFloat newFontPointSize = currentFontPointSize * MAX(kFontMultiplier, 1);
    UIFont *newFont = [UIFont fontWithName:currrentFont.fontName size:newFontPointSize];
    if ([txtVw respondsToSelector:@selector(setFont:)]) {
        [txtVw setFont:newFont];
    }
}

//More Advanced
+ (void)addLinearGradientToView:(UIView *)theView withColor:(UIColor *)theColor transparentToOpaque:(BOOL)transparentToOpaque
{
    CAGradientLayer *gradient = [CAGradientLayer layer];
    
    //the gradient layer must be positioned at the origin of the view
    CGRect gradientFrame = theView.frame;
    gradientFrame.origin.x = 0;
    gradientFrame.origin.y = 0;
    gradient.frame = gradientFrame;
    
    //build the colors array for the gradient
    NSArray *colors = [NSArray arrayWithObjects:
                       (id)[theColor CGColor],
                       (id)[[theColor colorWithAlphaComponent:0.9f] CGColor],
                       (id)[[theColor colorWithAlphaComponent:0.6f] CGColor],
                       (id)[[theColor colorWithAlphaComponent:0.4f] CGColor],
                       (id)[[theColor colorWithAlphaComponent:0.3f] CGColor],
                       (id)[[theColor colorWithAlphaComponent:0.1f] CGColor],
                       (id)[[UIColor clearColor] CGColor],
                       nil];
    
    //reverse the color array if needed
    if(transparentToOpaque)
    {
        colors = [[colors reverseObjectEnumerator] allObjects];
    }
    
    //apply the colors and the gradient to the view
    gradient.colors = colors;
    
    [theView.layer insertSublayer:gradient atIndex:0];
}
@end
