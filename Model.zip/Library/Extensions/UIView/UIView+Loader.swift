//
//  UIView+Loader.swift
//  OnDemandApp
//  Created by Pawan Joshi on 18/04/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation

import MBProgressHUD


// MARK: - UIView Extension
extension UIView {
    
    // - MARK: - Loading Progress View
    func showLoader(mainTitle title: String!, subTitle subtitle: String?) {
        
        let hud = MBProgressHUD.showAdded(to: self, animated: true)
        hud?.labelText = title
        hud?.detailsLabelText = subtitle
        hud?.isSquare = true
        hud?.mode = .indeterminate
        //hud.color = Colors.themeColor()
    }
    
    func hideLoader() {
       // DispatchQueue.main.async {
            MBProgressHUD.hide(for: self, animated: true)
        //}

        
    }
    
    func hideAllLoader() {
        
        DispatchQueue.main.async {
            MBProgressHUD.hideAllHUDs(for: self, animated: true)
        }
        
    }
}


extension UIView {
    
    func changeCornerStyle(){
        
        self.layer.cornerRadius = 5.0
        self.clipsToBounds = true
        self.layer.borderColor = UIColor.black.cgColor
        self.layer.borderWidth = 0.5
        
    }
    
    func changeCornerAndColor(_ radius:CGFloat, borderWidth:CGFloat, color:CGColor){
        
        self.layer.cornerRadius = radius
        self.clipsToBounds = true
        self.layer.masksToBounds = true
        self.layer.borderWidth = borderWidth
        self.layer.borderColor = color
        
    }
    
}
