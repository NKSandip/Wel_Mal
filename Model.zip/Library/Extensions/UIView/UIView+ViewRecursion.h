//
//  UIView+ViewRecursion.h
//  2Stones
//
//  Created by Hemant Sharma on 05/12/15.
//  Copyright © 2015 2Stones. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (ViewRecursion)

- (NSMutableArray*)allSubViews;

@end
