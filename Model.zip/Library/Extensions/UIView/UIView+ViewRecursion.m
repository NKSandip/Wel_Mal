//
//  UIView+ViewRecursion.m
//  2Stones
//
//  Created by Hemant Sharma on 05/12/15.
//  Copyright © 2015 2Stones. All rights reserved.
//

#import "UIView+ViewRecursion.h"

@implementation UIView (ViewRecursion)

- (NSMutableArray*)allSubViews
{
    NSMutableArray *arr = [[NSMutableArray alloc] init];
    [arr addObject:self];
    for (UIView *subview in self.subviews)
    {
        [arr addObjectsFromArray:(NSArray*)[subview allSubViews]];
    }
    return arr;
}
@end
