//
//  Helper.swift
//  OnDemandApp
//  Created by Sourabh Bhardwaj on 15/04/16.
//  Copyright © 2016 Appster. All rights reserved.
//


import Foundation

let DEVICE_ID_KEY = "deviceID"
let DEVICE_TYPE = "iOS"
let ACCESS_TOKEN_KEY = "accessToken"

/**
 Global function to check if the input object is initialized or not.
 
 - parameter value: value to verify for initialization
 
 - returns: true if initialized
 */
public func isObjectInitialized (_ value: AnyObject?) -> Bool {
    guard let _ = value else {
        return false
    }
    return true
}


// MARK: Directory Path helper methods

public func documentsDirectoryPath () -> String? {
    return NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).first
}

public let documentsDirectoryURL: URL = {
    let urls = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
    return urls[urls.endIndex - 1]
}()

public let cacheDirectoryURL: URL = {
    let urls = FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask)
    return urls[urls.endIndex - 1]
}()


// MARK: Access token getter and setter

public func accessToken () -> String? {
    if UserManager.sharedManager().isUserLoggedIn() {
        return UserManager.sharedManager().activeUser.accessToken
    }
    //For Guet User
    return "Guest"
}


// MARK: API helper methods

public func deviceId () -> String {
    
    if let deviceID = UserDefaults.objectForKey(DEVICE_ID_KEY) {
        return deviceID as! String
    } else {
        let deviceID = UIDevice.current.identifierForVendor?.uuidString ?? ""
        UserDefaults.setObject(deviceID as AnyObject?, forKey: DEVICE_ID_KEY)
        return deviceID
    }
}

public func deviceInfo () -> [String: String] {
    
    var deviceInfo = [String: String]()
    deviceInfo["deviceId"] = deviceId()
    deviceInfo["deviceType"] = "1" // for iOS as asked in API
    deviceInfo["deviceToken"] = AppDelegate.delegate().deviceToken()
    deviceInfo["deviceOS"] = DEVICE_TYPE
    deviceInfo["deviceModel"] = UIDevice.current.model
    deviceInfo["deviceOSVersion"] = UIDevice.current.systemVersion
    return deviceInfo
}

public func getDateAndTime(dateInString:String) -> String {
    
    let dateFormatter = DateFormatter()
    let locale = NSLocale.init(localeIdentifier: "en_US") as Locale
    dateFormatter.locale = locale
    dateFormatter.dateFormat = "yyyy-MM-dd"
    let date = dateFormatter.date(from: dateInString)
    dateFormatter.dateFormat = "dd MMM yyyy"
    if (date != nil) {
        let selectedTime = dateFormatter.string(from: date!)
        let array = selectedTime.components(separatedBy: " ")
        let daySufix = Int(array.first!)?.suffix().uppercased()
        let month = array[1].uppercased()
        let year = array.last
        let dateToreturn = "\(array.first!)\(daySufix!) \(month) \(year!)"
        return dateToreturn
    }
    
    return ""
   
}

public func getDateFromStringInyyyyMMdd(dateInString:String) -> Date {

    let dateFormatter = DateFormatter()
    let locale = NSLocale.init(localeIdentifier: "en_US") as Locale
    dateFormatter.locale = locale
    dateFormatter.dateFormat = "yyyy-MM-dd"
    let date = dateFormatter.date(from: dateInString)
    return date!
}

public func getProgressPercentage(startDate:Date, endDate:Date) -> Double{
    
    let startTime  = startDate.startOfDay
    let endTime = endDate.endOfDay
    let totalTime = endTime?.timeIntervalSince(startTime as Date)
    let timeLeft = Date().timeIntervalSince(startTime as Date)
    return timeLeft/totalTime!
}


public func getDateAndTimeForHireJobDetail(dateInString:String) -> String {
    let dateFormatter = DateFormatter()
    let locale = NSLocale.init(localeIdentifier: "en_US") as Locale
    dateFormatter.locale = locale
    dateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
    let date = dateFormatter.date(from: dateInString)
    dateFormatter.dateFormat = "dd MMM yyyy"
    let selectedTime = dateFormatter.string(from: date!)
    let array = selectedTime.components(separatedBy: " ")
    let daySufix = Int(array.first!)?.suffix().uppercased()
    let month = array[1].uppercased()
    let year = array.last
    let dateToreturn = "\(array.first!)\(daySufix!) \(month) \(year!)"
    return dateToreturn
}

public func maskWithColor(color: UIColor,image:UIImage) -> UIImage? {
    let maskImage = image.size
    
    let width = maskImage.width
    let height = maskImage.height
    let bounds = CGRect(x: 0, y: 0, width: width, height: height)
    
    let colorSpace = CGColorSpaceCreateDeviceRGB()
    let bitmapInfo = CGBitmapInfo(rawValue: CGImageAlphaInfo.premultipliedLast.rawValue)
    let context = CGContext(data: nil, width: Int(width), height: Int(height), bitsPerComponent: 8, bytesPerRow: 0, space: colorSpace, bitmapInfo: bitmapInfo.rawValue)!
    
    context.clip(to: bounds, mask: image as! CGImage)
    context.setFillColor(color.cgColor)
    context.fill(bounds)
    
    if let cgImage = context.makeImage() {
        let coloredImage = UIImage(cgImage: cgImage)
        return coloredImage
    } else {
        return nil
    }
}

/**
 Add additional parameters to an existing dictionary
 
 - parameter params: parameters dictionary
 
 - returns: returns final dictionary
 */
func addAdditionalParameters (_ params: [String: AnyObject]) -> [String: AnyObject] {
    
    var finalParams = params
    finalParams["deviceInfo"] = deviceInfo() as AnyObject?
    return finalParams
}

/**
 Method used to handle api response and based on the status it calls completion handler
 
 - parameter response:   api response
 - parameter completion: completion handler
 */
func handleApiResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
    LogManager.logDebug("response = \(response)")
    
    if response.success {
        completion(true, nil)
    } else {
        completion(false, response.responseError)
    }
}


// MARK: Application info methods
/**
 Get version of application.
 
 - returns: Version of app
 */
func applicationVersion () -> String {
    let info: NSDictionary = Bundle.main.infoDictionary! as NSDictionary
    return  info.object(forKey: "CFBundleVersion") as! String
}

/**
 Get bundle identifier of application.
 
 - returns: NSBundle identifier of app
 */
func applicationBundleIdentifier () -> NSString {
    return Bundle.main.bundleIdentifier! as NSString
}

/**
 Get name of application.
 
 - returns: Name of app
 */
func applicationName () -> String {
    let info:NSDictionary = Bundle.main.infoDictionary! as NSDictionary
    return  info.object(forKey: "CFBundleDisplayName") as! String
}

public func requiredRowHeight(text:String, width:CGFloat, fontName:String, fontSize:CGFloat) -> CGFloat{
    
    let font = UIFont(name: fontName, size: fontSize)
    let label:UILabel = UILabel(frame: CGRect(x:0, y:0,width: width
        , height: CGFloat.greatestFiniteMagnitude))
    label.numberOfLines = 0
    label.lineBreakMode = .byWordWrapping
    label.font = font
    label.text = text
    label.sizeToFit()
    return label.frame.height //+ 10 //126
}

public func timeIsInAmPm() -> Bool{

    let formatString: NSString = DateFormatter.dateFormat(fromTemplate: "j", options: 0, locale: NSLocale.current)! as NSString
    let hasAMPM = formatString.contains("a")
    return hasAMPM
}

public func printAvailableFonts(){

    //Check which fonts available
    for family: String in UIFont.familyNames
    {
        LogManager.logDebug("\(family)")
        for names: String in UIFont.fontNames(forFamilyName: family)
        {
            LogManager.logDebug("== \(names)")
        }
    }
}

extension Int {
    
    public func suffix() -> String {
        let absSelf = abs(self)
        
        switch (absSelf % 100) {
            
        case 11...13:
            return "TH"
        default:
            switch (absSelf % 10) {
            case 1:
                return "ST"
            case 2:
                return "ND"
            case 3:
                return "RD"
            default:
                return "TH"
            }
        }
    }
}
