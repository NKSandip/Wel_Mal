//
//  LoaderHelper.swift
//  ManMoji
//
//  Created by Pawan Joshi on 10/08/17.
//  Copyright © 2017 Appster. All rights reserved.
//

import Foundation
import UIKit
class LoaderHelper: NSObject {
    
    public override init() {
        super.init()
    }
    
    // MARK: Loader methods
    class func showLoaderWithText(text: String) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        if UIApplication.shared.isIgnoringInteractionEvents == false {
            UIApplication.shared.beginIgnoringInteractionEvents()
        }
        SVProgressHUD.show(withStatus: text)
    }
    
    class func setLoaderText(text: String) {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        SVProgressHUD.setStatus(text)
        if UIApplication.shared.isIgnoringInteractionEvents == false {
            UIApplication.shared.beginIgnoringInteractionEvents()
        }
    }
    
    class func configureLoader() {
        SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.dark)
        SVProgressHUD.setDefaultAnimationType(SVProgressHUDAnimationType.native)
    }
    
    class func showLoader() {
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
        if UIApplication.shared.isIgnoringInteractionEvents == false {
            UIApplication.shared.beginIgnoringInteractionEvents()
        }
        SVProgressHUD.show()
    }
    
    
    
    class func hideLoader() {
        UIApplication.shared.isNetworkActivityIndicatorVisible = false
        UIApplication.shared.endIgnoringInteractionEvents()
        SVProgressHUD.dismiss()
    }
    
}
