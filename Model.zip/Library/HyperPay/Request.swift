import UIKit

//TODO: This class uses our test integration server; please adapt it to use your own backend API.
class Request: NSObject {
    
    // Test merchant server domain
    static func requestCheckoutID(amount: Double, currency: String, completion: @escaping (String?) -> Void) {
        let parameters: [String:String] = [
            "amount": String(format: "%.2f", amount),
            "currency": currency,
            "shopperResultUrl": Config.schemeURL + "://payment",
            "paymentType": "DB",
//            "testMode": "EXTERNAL"
            // "testMode": "INTERNAL"
        ]
        var parametersString = ""
        for (key, value) in parameters {
            parametersString += key + "=" + value + "&"
        }
        parametersString.remove(at: parametersString.index(before: parametersString.endIndex))
        let url = Constants.APIServiceMethods.getCheckOutReqestAPI + "/token?" + parametersString.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let request = NSURLRequest(url: URL(string: url)!)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            if let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: Any] {
                let checkoutID = json?["id"] as? String
                completion(checkoutID)
            } else {
                completion(nil)
            }
        }.resume()
    }
    
    static func requestPaymentStatus(resourcePath: String, completion: @escaping (Bool,NSDictionary?) -> Void) {
        let url = Constants.APIServiceMethods.getPaymentStatusReqestAPI + "/status?resourcePath=" + resourcePath.addingPercentEncoding(withAllowedCharacters: .urlQueryAllowed)!
        let request = NSURLRequest(url: URL(string: url)!)
        URLSession.shared.dataTask(with: request as URLRequest) { (data, response, error) in
            if let data = data, let json = try? JSONSerialization.jsonObject(with: data, options: []) as? [String: AnyObject] {
                let transactionStatus = json?["result"] as? NSDictionary?
                let transactionCode = transactionStatus?!["code"] as? NSString?
                if (transactionCode!?.isEqual(to: "000.000.000"))!{
                    completion(true,json! as NSDictionary?)
                }else{
                    completion(false,NSDictionary.init())
                }
//                let transactionMsg = transactionStatus?!["description"] as? NSString?
//                completion((transactionCode!?.isEqual(to: "000.000.000"))!,json! as NSDictionary?)
                /*if transactionCode == "000.000.000" {// &&  transactionMsg == "Transaction succeeded"
                    println("These two strings are considered equal")
                    completion(transactionStatus == "OK",json! as NSDictionary?)
                }*/
                
            } else {
                completion(false,NSDictionary.init())
            }
        }.resume()
    }
}
