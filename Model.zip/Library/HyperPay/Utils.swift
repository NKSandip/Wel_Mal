import UIKit

class Utils: NSObject {

    static func SDKVersion() -> String? {
        if let path = Bundle.main.path(forResource: "OPPWAMobile-Resources.bundle/version", ofType: "plist") {
            if let versionDict = NSDictionary(contentsOfFile: path) as? [String: String] {
                return versionDict["OPPVersion"]
            }
        }
        return ""
    }
    
    static func amountAsString() -> String {
        return String(format: "%.2f", Config.amount) + " " + Config.currency
    }
    
    static func showResult(presenter: UIViewController, success: Bool, message: String?) {
        let title = success ? "Success" : "Failure"
        let alert = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        presenter.present(alert, animated: true, completion: nil)
    }
    
    static func configureCheckoutSettings() -> OPPCheckoutSettings {
        let checkoutSettings = OPPCheckoutSettings()
        checkoutSettings.paymentBrands = Config.checkoutPaymentBrands
        let securityPolicyForTokens = OPPSecurityPolicy(forTokensWith: .deviceAuthRequired)
        let securityPolicyForPaymentBrands = OPPSecurityPolicy(paymentBrands: checkoutSettings.paymentBrands, mode: .deviceAuthRequiredIfAvailable)
        checkoutSettings.schemeURL = Config.schemeURL
        
        checkoutSettings.theme.navigationBarBackgroundColor = Config.mainColor
        checkoutSettings.theme.confirmationButtonColor = Config.mainColor
        checkoutSettings.theme.cellHighlightedBackgroundColor = Config.mainColor
        checkoutSettings.theme.sectionBackgroundColor = Config.mainColor.withAlphaComponent(0.05)
        
        checkoutSettings.securityPolicies = [securityPolicyForPaymentBrands, securityPolicyForTokens]
        
        return checkoutSettings
    }
}
