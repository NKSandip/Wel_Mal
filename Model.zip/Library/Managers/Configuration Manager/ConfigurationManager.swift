//
//  ConfigurationManager.swift
//  OnDemandApp
//  Created by Pawan Joshi on 03/02/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import UIKit

final class ConfigurationManager: NSObject {
    
    var environment: NSDictionary!
    var configDict: NSDictionary!
    
    // MARK: - Singleton Instance
    fileprivate static let _sharedManager = ConfigurationManager()
    
    class func sharedManager() -> ConfigurationManager {
        return _sharedManager
    }
    
    fileprivate override init() {
        super.init()
        
        // customize initialization
        initialize()
    }
    
    
    // MARK: Private Method
    
    fileprivate func initialize () {
        
        var environments: NSDictionary?
        if let envsPlistPath = Bundle.main.path(forResource: "Environments", ofType: "plist") {
            environments = NSDictionary(contentsOfFile: envsPlistPath)
        }
        
        self.environment = environments!.object(forKey: currentConfiguration()) as? NSDictionary
        self.configDict = environments!.object(forKey: "AppConfiguration") as? NSDictionary
        
        if (self.environment == nil || self.configDict == nil) {
            
            assertionFailure(NSLocalizedString("Unable to load application configuration", comment:"Unable to load application configuration"))
        }
    }
    
    
    // MARK: - Public Methods
    
    func currentConfiguration () -> String {
        
        let configuration = Bundle.main.infoDictionary?["ActiveConfiguration"] as? String
        return configuration!
    }
    
    func APIEndPoint () -> String {
        let configuration = self.environment!["APIEndPoint"]
        return (configuration)! as! String//"https://api.e3mal.co/api/v1"//
//        if ConfigurationManager.sharedManager().isMultiService(){
//            let configuration = self.environment!["APIEndPoint"]
//            return (configuration)! as! String
//        }else{
//            let configuration = self.environment!["APIEndPoint"]
//            return (configuration)! as! String
//        }
        
    }
    
    func APIServer() -> String {
        let configuration = self.environment!["APIServer"]
        return (configuration)! as! String
    }
    
    func APIEndPointForEmailVerification () -> String {
        if ConfigurationManager.sharedManager().isMultiService(){
            let configuration = self.environment!["APIEndPoint"]
            return (configuration)! as! String
        }else{
            let configuration = self.environment!["APIEndPoint"]
            return (configuration)! as! String
        }
    }
    
    func isLoggingEnabled () -> Bool {
        
        let configuration = self.environment!["LoggingEnabled"]
        return (configuration)! as! Bool
    }
    
    func isAnalyticsTrackingEnabled () -> String {
        
        let configuration = self.environment!["AnalyticsTrackingEnabled"]
        return (configuration)! as! String
    }
    
    //MARK:- Provider & Seeker Configurations
    
    func isEmailVerificationOn() -> Bool {
        
        var configuration = false
        if(UserManager.sharedManager().userType == .userTypeSeeker)
        {
            let dictConfig = self.configDict!["Seeker"] as! NSDictionary
            configuration  = dictConfig["isEmailVerificationOn"] as! Bool

            
        }
        else
        {
            let dictConfig = self.configDict!["Provider"] as! NSDictionary
            configuration  = dictConfig["isEmailVerificationOn"] as! Bool

            
        }
        return configuration
    }
    
    func isOtpEnabled() -> Bool {
        
        var configuration = false
        if(UserManager.sharedManager().userType == .userTypeSeeker)
        {
            let dictConfig = self.configDict!["Seeker"] as! NSDictionary
            configuration  = dictConfig["isOtpEnabled"] as! Bool
            
        }
        else
        {
            let dictConfig = self.configDict!["Provider"] as! NSDictionary
            configuration  = dictConfig["isOtpEnabled"] as! Bool

            
        }
        return configuration
    }
    
    func isStoreLocationRequired() -> Bool {
        
        var configuration = false
        if(UserManager.sharedManager().userType == .userTypeSeeker)
        {
            let dictConfig = self.configDict!["Seeker"] as! NSDictionary
            configuration  = dictConfig["StoreLocationRequired"] as! Bool

            
        }
        else
        {
            let dictConfig = self.configDict!["Provider"] as! NSDictionary
            configuration  = dictConfig["StoreLocationRequired"] as! Bool

            
        }
        return configuration
    }
    
    func isMultiService() -> Bool {
        
        var configuration = false
        if(UserManager.sharedManager().userType == .userTypeSeeker)
        {
            let dictConfig = self.configDict!["Seeker"] as! NSDictionary
            configuration  = dictConfig["MultiService"] as! Bool

            
        }
        else
        {
            let dictConfig = self.configDict!["Provider"] as! NSDictionary
            configuration  = dictConfig["MultiService"] as! Bool

            
        }
        return configuration
    }
    
    func isPaymentEnabled() -> Bool {
        
        var configuration = false
        if(UserManager.sharedManager().userType == .userTypeSeeker)
        {
            let dictConfig = self.configDict!["Seeker"] as! NSDictionary
            configuration  = dictConfig["isPaymentEnabled"] as! Bool

        }
        else
        {
            let dictConfig = self.configDict!["Provider"] as! NSDictionary
            configuration  = dictConfig["isPaymentEnabled"] as! Bool

        }
        return configuration
    }
}

extension ConfigurationManager {
    
    func googleAppId() -> String {
        let googleID = self.environment!["GoogleApiKey"]
        
        if googleID == nil {
            assert(googleID != nil, "Please supply googleID Api Key in Project Directory > Library > Managers > Configration Manager -> Enviroments.plist")
            return ""
        } else {
            return googleID as! String
        }
    }
    
    // MARK: Twitter
    func twitterAppId() -> (twitterClientID: String, twitterClientSecretID: String) {
        
        if let twitterAppID: NSDictionary? = self.environment!["TwitterAppID"] as? NSDictionary , twitterAppID!["TwitterClientID"] != nil && twitterAppID!["TwitterClientSecrateID"] != nil {
            return (twitterAppID!["TwitterClientID"] as! String, twitterAppID!["TwitterClientSecrateID"] as! String)
        }
        else {
            assertionFailure("Please supply Twitter Client ID and Twitter Client Secret ID in Project Directory > Library > Managers > Configration Manager -> Enviroments.plist")
            return ("", "")
        }
    }
    
    
    // MARK: LinkedIn
    func linkedInAppId() -> String {
        let linkedInAppId = self.environment!["LinkedInAppId"]
        if linkedInAppId == nil {
            assert(linkedInAppId != nil, "Please supply Linked In App ID in Project Directory > Library > Managers > Configration Manager -> Enviroments.plist")
            return ""
        } else {
            return linkedInAppId as! String
        }
    }
}
