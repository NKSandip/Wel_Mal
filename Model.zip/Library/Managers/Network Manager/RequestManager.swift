//
//  NetworkManager.swift
//  OnDemandApp
//  Created by Pawan Joshi on 20/02/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import UIKit
import Reachability

public enum HTTPRequestErrorCode : Int {
    
    case httpConnectionError = 40 // Trouble connect`ing to Server.
    case httpInvalidRequestError = 50 // Your request had invalid parameters.
    case httpResultError = 60 // API result error (eg: Invalid username and password).
}

class RequestManager: NSObject {
    
    fileprivate var _urlSession : URLSession?
    fileprivate var _runningURLRequests : NSSet?
    
    static var networkFetchingCount : Int = 0
    
    // MARK: - Class Methods
    
    static func beginNetworkActivity () -> () {
        networkFetchingCount += 1
        UIApplication.shared.isNetworkActivityIndicatorVisible = true
    }
    
    /**
     Call to hide network indicator in Status Bar
     */
    static func endNetworkActivity() -> () {
        if networkFetchingCount > 0 {
            networkFetchingCount -= 1
        }
        
        if networkFetchingCount == 0 {
            UIApplication.shared.isNetworkActivityIndicatorVisible = false
        }
    }
    
    
    // MARK: - Singleton Instance
    fileprivate static let _sharedManager = RequestManager()
    
    class func sharedManager() -> RequestManager {
        return _sharedManager
    }
    
    fileprivate override init() {
        super.init()
        // customize initialization
    }
    
    
    // MARK: - Private Methods
    /**
     Craete Urlsession from default configuration.
     
     - returns: instance of Url Session.
     */
    fileprivate func urlSession () -> URLSession {
        if _urlSession == nil {
            _urlSession = URLSession(configuration: URLSessionConfiguration.default)
            //            _urlSession?.sessionDescription! = "networkmanager.nsurlsession"
        }
        return _urlSession!
    }
    
    
    // MARK: - Public Methods
    /**
     Perform request to fetch data
     
     - parameter request:           request
     - parameter userInfo:          userinfo
     - parameter completionHandler: handler
     */
    func performRequest(_ request: NSMutableURLRequest, userInfo: NSDictionary? = nil, completionHandler: @escaping (_ response: Response) -> Void) -> () {
        guard isNetworkReachable() else {
            let resError: NSError = errorForNoNetwork()
            let res = Response(error: resError)
            completionHandler(res)
            return // do not proceed if user is not connected to internet
        }
        
        // Set required headers
        //if UserManager.sharedManager().isUserLoggedIn() {
            LogManager.logDebug("accessToken -- \(accessToken())")
            LogManager.logDebug("deviceId -- \(deviceId())")
            request.addValue(accessToken()!, forHTTPHeaderField: "accessToken")
            request.addValue(deviceId(), forHTTPHeaderField: "deviceId")
            
            LogManager.logDebug("\(accessToken()!)")
            LogManager.logDebug("\(deviceId())")

        //}
        
        self.performSessionDataTaskWithRequest(request, completionHandler: completionHandler)
    }
    
    /**
     Perform session data task
     
     - parameter request:           url request
     - parameter userInfo:          user information
     - parameter completionHandler: completion handler
     */
   /* fileprivate func performSessionDataTaskWithRequest(_ request: NSMutableURLRequest, userInfo: NSDictionary? = nil, completionHandler: @escaping (_ response: Response) -> Void) -> () {
        
        RequestManager.beginNetworkActivity()
        
        self.addRequestedURL(request.url!)
        
        let session: URLSession = self.urlSession()
        session.dataTask(with: request, completionHandler: { (data, response, error) in
            
            RequestManager.endNetworkActivity()
            
            var responseError: NSError? = error
            
            // handle http response status
            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode > 200 {
                    responseError = self.errorForStatus(httpResponse.statusCode)
                }
            }
            
            var apiResponse: Response?
            if let _ = responseError {
                apiResponse = Response(data: data)
                
                if let _ = apiResponse?.resultDictionary {
                    
                }else{
                    apiResponse = Response(error: responseError)
                    self.logError(apiResponse!.responseError!, request: request)
                }
                
            } else {
                apiResponse = Response(data: data)
                self.logResponse(data!, forRequest: request)
            }
            
            self.removeRequestedURL(request.url!)
            
            DispatchQueue.main.async(execute: { () -> Void in
                completionHandler(response: apiResponse!)
            })
            }) .resume()
    }*/
    
    
    fileprivate func performSessionDataTaskWithRequest(_ request: NSMutableURLRequest, userInfo: NSDictionary? = nil, completionHandler: @escaping (_ response: Response) -> Void) -> () {
        
        RequestManager.beginNetworkActivity()
        
        self.addRequestedURL(request.url!)
        
        let session: URLSession = self.urlSession()
        
        session.dataTask(with: request as URLRequest) { (data, response, error) in
            
            RequestManager.endNetworkActivity()
            
            var responseError: NSError? = error as NSError?
            
            // handle http response status
            if let httpResponse = response as? HTTPURLResponse {
                if httpResponse.statusCode > 200 {
                    responseError = self.errorForStatus(httpResponse.statusCode)
                }
            }
            
            var apiResponse: Response?
            if let _ = responseError {
                apiResponse = Response(data: data)
                
                if let _ = apiResponse?.resultDictionary {
                    
                }else{
                    apiResponse = Response(error: responseError)
                    self.logError(apiResponse!.responseError!, request: request)
                }
                
            } else {
                apiResponse = Response(data: data)
                self.logResponse(data!, forRequest: request)
            }
            
            self.removeRequestedURL(request.url!)
            DispatchQueue.global().async (execute: { () -> Void in
                
                if let statusCode = apiResponse?.resultDictionary?.value(forKey: "statusCode"){
                    if  "\((statusCode))" == "401" && UserManager.sharedManager().isUserLoggedIn(){
                        NotificationCenter.default.post(name: Constants.NOTIFICATION_LOGOUT, object: self, userInfo: ["unreadCount":"99+"])
                    }
                }
//                if apiResponse?.message() == "Authenitication required" || apiResponse?.message() == "Authenitication \"U0645\"U0637\"U0644\"U0648\"U0628"{
//                    
//                }
                completionHandler(apiResponse!)
            })
            }.resume()
        
    }
    
    
    /**
     Perform http action for a method
     
     - parameter method:            HTTP method
     - parameter urlString:         url string
     - parameter params:            parameters
     - parameter completionHandler: completion handler
     */
    func performHTTPActionWithMethod (_ method: HTTPRequestMethod, urlString: String, params: [String: AnyObject]? = nil, completionHandler: @escaping (_ response: Response) -> Void) {
        if method == .GET {
            var components = URLComponents(string: urlString)
            components?.queryItems = params?.queryItems() as [URLQueryItem]?
            
            if let url = components?.url {
                let request = NSMutableURLRequest(url: url)
                request.httpMethod = HTTPRequestMethod.GET.rawValue
                request.cachePolicy = NSURLRequest.CachePolicy(rawValue: 4)!
                request.timeoutInterval = NSMutableURLRequest.requestTimeoutInterval()
                request.setValue(Localisator.sharedInstance.currentLanguage, forHTTPHeaderField: "language")
                self.performRequest(request, completionHandler: completionHandler)
            } else { // do not proceed if the url is nil
                let resError: NSError = errorForInvalidURL()
                let res = Response(error: resError)
                completionHandler(res)
            }
        } else {
            let request = NSMutableURLRequest.requestWithURL(URL(string: urlString)!, method: method, jsonDictionary: params as NSDictionary?)
            self.performRequest(request, completionHandler: completionHandler)
        }
    }
    
    fileprivate func logError (_ error: NSError , request: NSMutableURLRequest) {
        #if DEBUG
            LogManager.logDebug("URL: \(request.url?.absoluteString) Error: \(error.localizedDescription)")
        #endif
    }
    
    fileprivate func logResponse (_ data: Data , forRequest request: NSMutableURLRequest) {
        #if DEBUG
            LogManager.logDebug("Data Size: \(data.count) bytes")
            let output: NSString = NSString(data: data, encoding: String.Encoding.utf8.rawValue)!
            LogManager.logDebug("URL: \(request.url?.absoluteString) Output: \(output)")
        #endif
    }
}

// MARK: Request handling methods
extension RequestManager {
    
    /**
     Add a Url to request Manager.
     
     - parameter url: URL
     */
    fileprivate func addRequestedURL (_ url: URL) {
        objc_sync_enter(self)
        let requests: NSMutableSet = (self.runningURLRequests().mutableCopy()) as! NSMutableSet
        if let urlString: URL = url {
            requests.add(urlString)
            _runningURLRequests = requests
        }
        objc_sync_exit(self)
    }
    
    /**
     Remove url from Manager.
     
     - parameter url: URL
     */
    fileprivate func removeRequestedURL (_ url: URL) {
        objc_sync_enter(self)
        let requests: NSMutableSet = (self.runningURLRequests().mutableCopy()) as! NSMutableSet
        if let urlString: URL = url {
            if(requests.contains(url) == true) {
                requests.remove(urlString)
                _runningURLRequests = requests
            }
        }
        objc_sync_exit(self)
    }
    
    /**
     get currently running requests
     
     - returns: return set of running requests
     */
    fileprivate func runningURLRequests () -> NSSet {
        if _runningURLRequests == nil {
            _runningURLRequests = NSSet()
        }
        return _runningURLRequests!
    }
    
    /**
     Check wheather requesting fro URL.
     
     - parameter URl: url to check.
     
     - returns: true if current request.
     */
    fileprivate func isProcessingURL (_ url: URL) -> Bool {
        return self.runningURLRequests().contains(url)
    }
    
    /**
     Cancel session for a URL.
     
     - parameter url: URL
     */
   /* func cancelRequestForURL (_ url: URL) {
        self.urlSession().getTasksWithCompletionHandler({(dataTasks: [URLSessionDataTask], uploadTasks: [URLSessionUploadTask], downloadTasks: [URLSessionDownloadTask]) -> Void in
            
            let capacity: NSInteger = dataTasks.count + uploadTasks.count + downloadTasks.count
            let tasks: NSMutableArray = NSMutableArray(capacity: capacity)
            tasks.addObjects(from: dataTasks)
            tasks.addObjects(from: uploadTasks)
            tasks.addObjects(from: downloadTasks)
            let predicate: NSPredicate = NSPredicate(format: "originalRequest.URL = %@", url as CVarArg)
            tasks.filter(using: predicate)
            
            for task in tasks {
                (task as AnyObject).cancel()
            }
        })
    }*/
    
    /**
     Cancel All Running Requests
     */
    func cancelAllRequests () {
        self.urlSession().invalidateAndCancel()
        _urlSession = nil
        _runningURLRequests = nil
    }
}


// MARK: Error handling methods
extension RequestManager {
    
    /**
     Get Error instances if Nil URL.
     
     - returns: Error instance.
     */
    fileprivate func errorForInvalidURL () -> NSError {
        return NSError(domain: NSURLErrorDomain , code: -1, userInfo: [NSLocalizedFailureReasonErrorKey: "URL must not be nil"])
    }
    
    /**
     Get Error instances for NoNetwork.
     
     - returns: Error instance.
     */
    fileprivate func errorForNoNetwork () -> NSError {
        return NSError(domain: NSURLErrorDomain, code: HTTPRequestErrorCode.httpConnectionError.rawValue, userInfo: [NSLocalizedFailureReasonErrorKey: "Network not available"])
    }
    
    /**
     Get Error instances for connectionError.
     
     - returns: connectionError instance.
     */
    fileprivate func connectionError () -> NSError {
        let errorDict = [NSLocalizedDescriptionKey: NSLocalizedString("Connection Error", comment: "Connection Error"),NSLocalizedFailureReasonErrorKey: NSLocalizedString("Network error occurred while performing this task. Please try again later.", comment: "Network error occurred while performing this task. Please try again later.")]
        let error: NSError = NSError(domain: kHTTPRequestDomain, code: HTTPRequestErrorCode.httpConnectionError.rawValue, userInfo: errorDict)
        return error
    }
    
    /**
     Create an error for response you probably don't want (400-500 HTTP responses for example).
     
     - parameter code: Code for error.
     
     - returns: An NSError.
     */
    fileprivate func errorForStatus(_ code: Int) -> NSError {
        let text = NSLocalizedString(HTTPStatusCode(statusCode: code).statusDescription, comment: "")
        return NSError(domain: "HTTP", code: code, userInfo: [NSLocalizedDescriptionKey: text])
    }
}


// MARK: Network reachable methods
extension RequestManager {
    
    /**
     Check wheather network is reachable.
     
     - returns: true is reachable otherwise false.
     */
    fileprivate func isNetworkReachable () -> Bool {
        let reach: Reachability = Reachability.forInternetConnection()
        return reach.currentReachabilityStatus() != .NotReachable
    }
    
    /**
     Check wheather WiFi is reachable.
     
     - returns: true is reachable otherwise false.
     */
    fileprivate func isReachableViaWiFi () -> Bool {
        let reach: Reachability = Reachability.forInternetConnection()
        return reach.currentReachabilityStatus() != .ReachableViaWiFi
    }
}
