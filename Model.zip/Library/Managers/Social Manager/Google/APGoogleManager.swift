//
//  APGoogleManager.swift
//  OnDemandApp
//
//  Created by Shwetabh Singh on 08/07/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation
import Google

// Completion Handler returns user or error
typealias GoogleCompletionHandler = (_ userDict: [String : String]?, _ error: NSError?) -> Void

class APGoogleManager : NSObject {
    
    fileprivate static let manager = APGoogleManager()
    
    var googleCompletionHandler : GoogleCompletionHandler?
    var fromController: UIViewController!
    var user : [String : String]? = [String : String]()
    
    var configuration: GoogleConfiguration = GoogleConfiguration.defaultConfiguration()
    
    var uiDelegate: GIDSignInUIDelegate? {
        get {
            return GIDSignIn.sharedInstance().uiDelegate
        }
        set {
            GIDSignIn.sharedInstance().uiDelegate = newValue
        }
    }
    
    override init() {
        super.init()
        GIDSignIn.sharedInstance().delegate = self
    }
    
    // MARK: - Singleton Instance
    /**
     Initializes APGoogleManager class to have a new instance of manager
     
     - parameter config: requires a GoogleConfiguration instance which is required to configure the manager
     
     - returns: an instance of APGoogleManager which can be accessed via sharedManager()
     */
    class func managerWithConfiguration(_ config: GoogleConfiguration!) -> APGoogleManager {
        
        if config != nil {
            manager.configuration = config!
            manager.configuration.isConfigured = true
        }
        return self.manager
    }
    
    
    class func sharedManager() -> APGoogleManager {
        if isManagerConfigured() == false {
           _ = managerWithConfiguration(GoogleConfiguration.defaultConfiguration())
        }
        return self.manager
    }
    
    // MARK: - Helpers for Manager
    fileprivate class func isManagerConfigured() -> Bool {
        return self.manager.configuration.isConfigured
    }
    
    /**
     Reset your Manager
     */
    class func resetManager() {
        self.manager.configuration.isConfigured = false
    }
    
    /**
     method for Google Login. Returns dictionary with format {"email" : "" , "googleID" : "" , "name" : "" , "profilePicture" : "" , "google_IdToken" : ""}
     
     - parameter fromController: source view controller from which login should be prompted.
     - parameter handler:        return with SocialCompletionHandler, either valid social user or with error information
     */
    func loginFromController(_ sourceController: UIViewController, Handler handler: @escaping GoogleCompletionHandler) {
        self.googleCompletionHandler = handler
        self.fromController = sourceController
        self.uiDelegate = sourceController as? GIDSignInUIDelegate
        
        assert(self.fromController != nil, "Terminating app due to uncaught exception 'NSInvalidArgumentException', reason: 'uiDelegate must not be nil")
        GIDSignIn.sharedInstance().signIn()
    }
    
    /**
     Perform Logout
     */
    func logout() {
        //self.user = nil
        GIDSignIn.sharedInstance().signOut()
    }
    
    //    MARK: -
    /**
     Current User
     
     - returns: return Current User
     */
    func fetchProfileInfo(_ completion: GoogleCompletionHandler?) {
        
        self.googleCompletionHandler = completion
        
        let currentUser = GIDSignIn.sharedInstance().currentUser
        self.user?["email"] = currentUser?.profile.email
        self.user?["googleID"] = currentUser?.userID
        self.user?["name"] = currentUser?.profile.name
        if (currentUser?.profile.hasImage)! {
            self.user?["profilePicture"] = currentUser?.profile.imageURL(withDimension: 256).absoluteString
        }
        
        LogManager.logDebug("\(self.user)")
        
        if(self.googleCompletionHandler != nil) {
            self.googleCompletionHandler!(self.user , nil)
        }
    }
    
    /**
     Wrapper method to provide google login
     
     - parameter sourceVC:     Source view controller from which login should be prompted.
     - parameter successBlock: Gets callback once login is successful
     - parameter failureBlock: Gets callback if there is any error in the login process
     */
    //    func loginWithReadPermissions( permissions: [AnyObject]?, fromViewController sourceVC: UIViewController!, Completion handler: CompletionHandler) {
    //
    //        loginCompletionHandler = handler
    //    }
}

// MARK: - SignIN delegate

extension APGoogleManager: GIDSignInDelegate {
    
    @objc func sign(_ signIn: GIDSignIn!, didSignInFor user: GIDGoogleUser!,
                      withError error: Error!) {
        if (error == nil) {
            
            self.user?["email"] = user.profile.email
            self.user?["googleID"] = user.userID
            self.user?["name"] = user.profile.name
            self.user?["google_IdToken"] = user.authentication.idToken
            if user.profile.hasImage {
                self.user?["profilePicture"] = user.profile.imageURL(withDimension: 256).absoluteString
            }
            
            LogManager.logDebug("\(self.user)")
            
            self.googleCompletionHandler!(self.user , nil)
            
        } else {
            if self.googleCompletionHandler != nil {
                self.googleCompletionHandler!(nil , error as NSError?)
            }
            LogManager.logError("\(error.localizedDescription)")
        }
    }
    
    @objc func sign(_ signIn: GIDSignIn!, didDisconnectWith user:GIDGoogleUser!,
                      withError error: Error!) {
        // Perform any operations when the user disconnects from app here.
        // ...
    }
}


class GoogleConfiguration {
    
    var client_ID : String! = ""
    var scope : [String]! = []
    var isConfigured: Bool! = false
    
    init(client_ID: String, scope: [String]) {
        self.client_ID = client_ID
        self.scope = scope
    }
    
    class func defaultConfiguration() -> GoogleConfiguration {
        
        let gConfiguration = GoogleConfiguration(client_ID: "", scope: [""])
        
        // Initialize sign-in
        var configureError: NSError?
        GGLContext.sharedInstance().configureWithError(&configureError)
        assert(configureError == nil, "Error configuring Google services: \(configureError)")
        return gConfiguration
    }
    
}
