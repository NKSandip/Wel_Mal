//
//  APLinkedINManager.swift
//  E3malApp
//
//  Created by Shwetabh Singh on 10/11/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation

// Completion Handler returns user or error
typealias LinkedInCompletionHandler = (_ userDict: [String : String]?, _ error: NSError?) -> Void

class APLinkedINManager {
    
    var linkedInCompletionHandler : LinkedInCompletionHandler?
    static var sharedManager = APLinkedINManager()
    var user : [String : String]? = [String : String]()
    
    /**
     Login with linkedin which returns dictionary with format {"email" : "" , "accountID" : "" , "name" : "" , "profilePicture" : "" , "authToken" : ""}
     
     - parameter handler: return with LinkedInCompletionHandler, either valid user or with error information
     */
    func login(handler: @escaping LinkedInCompletionHandler) {
        
        self.linkedInCompletionHandler = handler
        self.loginWithLinkedInSDK()
    }
    
    func loginWithLinkedInSDK() {
        LISDKSessionManager.createSession(withAuth: [LISDK_BASIC_PROFILE_PERMISSION,LISDK_EMAILADDRESS_PERMISSION], state: nil, showGoToAppStoreDialog: true, successBlock: { (string) in
            if (LISDKSessionManager.hasValidSession()) {
                
                LISDKAPIHelper.sharedInstance().getRequest("https://api.linkedin.com/v1/people/~:(id,firstName,lastName,email-address,headline,picture-urls::(original),positions:(title))", success: { (response) in
                    
                    DispatchQueue.main.async {
                        if let dataFromString = response?.data.data(using: String.Encoding.utf8, allowLossyConversion: false) {
                            do {
                                let dictn : NSDictionary = try JSONSerialization.jsonObject(with: dataFromString, options: []) as! [String: AnyObject] as NSDictionary
                                self.userParser(userDict: dictn)
                                
                            } catch let error as NSError {
                                self.linkedInCompletionHandler!(nil , error)
                            }
                            
                        }                      }
                }, error: { (error) in
                    self.linkedInCompletionHandler!(nil , error)
                })
            }
        }) { (error) in
            self.linkedInCompletionHandler!(nil , error as NSError?)
        }
    }
    
    func userParser(userDict : NSDictionary) {
        self.user?["email"] = userDict.object(forKey: "emailAddress")! as? String
        self.user?["accountID"] = userDict.object(forKey: "id")! as? String
        self.user?["name"] = (userDict.object(forKey: "firstName")! as! String) + (userDict.object(forKey: "lastName")! as! String)
        
        //Getting profile pic
        let dictPic:NSDictionary = userDict.object(forKey: "pictureUrls") as! NSDictionary
        let arrPic:NSArray = dictPic.allKeys as NSArray
        if(arrPic.contains("values")){
            if ((((userDict.object(forKey: "pictureUrls") as! NSDictionary).object(forKey: "values"))) as! NSArray).count > 0 {
                self.user?["profilePicture"] = (((((userDict.object(forKey: "pictureUrls") as! NSDictionary).object(forKey: "values"))) as! NSArray).firstObject) as? String
            }
        }
        else {
            self.user?["profilePicture"] = ""
        }
        self.user?["authToken"] = LISDKSessionManager.sharedInstance().session.value()
        
        self.linkedInCompletionHandler!(self.user , nil)
        
    }
}
