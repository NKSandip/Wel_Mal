//
//  TwitterManager.swift
//  OnDemandApp
//
//  Created by Shwetabh Singh on 20/10/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation
import TwitterKit

// Completion Handler returns user or error
typealias TwitterCompletionHandler = (_ userDict: [String : String]?, _ error: NSError?) -> Void

class APTwitterManager {
    
    var twitterCompletionHandler : TwitterCompletionHandler?
    static var sharedManager = APTwitterManager()
    var user : [String : String]? = [String : String]()
    
    /**
     Login with twitter which returns dictionary with format {"email" : "" , "accountID" : "" , "name" : "" , "profilePicture" : "" , "authToken" : ""}
     
     - parameter handler: return with TwitterCompletionHandler, either valid user or with error information
     */
    
    func login(handler: @escaping TwitterCompletionHandler) {
        
        self.twitterCompletionHandler = handler
        loginWithTwitterSDK()
    }
    
    func loginWithTwitterSDK() {
        
        Twitter.sharedInstance().logIn(withMethods: [.webBased]) { session, error in
            if (session != nil) {
                LogManager.logDebug("signed in as \(session!.userName)");
                
                let client = TWTRAPIClient.withCurrentUser()
                let request = client.urlRequest(withMethod: "GET",
                                                url: "https://api.twitter.com/1.1/account/verify_credentials.json?include_email=true",
                                                          parameters: ["include_email": "true", "skip_status": "true"],
                                                          error: nil)
                
                client.sendTwitterRequest(request) { (response, data, error) -> Void in
                    
                    if let data = data {
                        do {
                            let post = try JSONSerialization.jsonObject(with: data,
                                                                                  options: []) as! NSDictionary
                            self.userParser(userDict: post)
                        } catch let error as NSError {
                            LogManager.logDebug("error: \(error.localizedDescription)");
                            self.twitterCompletionHandler!(nil , error)
                        }
                    } else if let error = error {
                        LogManager.logDebug("error: \(error.localizedDescription)")
                        self.twitterCompletionHandler!(nil , error as NSError?)
                    }
                }
                
            }
            else
            {
                LogManager.logDebug("error: \(error!.localizedDescription)");
                self.twitterCompletionHandler!(nil , error as NSError?)
            }
        }
    }
    
    func logoutUser() {
        if(Twitter.sharedInstance().sessionStore.session()?.authToken != nil) {
            Twitter.sharedInstance().sessionStore.logOutUserID((Twitter.sharedInstance().sessionStore.session()?.userID)!)
        }
    }
    
    func userParser(userDict : NSDictionary) {
        self.user?["email"] = userDict["email"] as? String
        self.user?["accountID"] = userDict["id_str"] as? String
        self.user?["name"] = userDict["name"] as? String
        self.user?["profilePicture"] = userDict["profile_image_url"] as? String
        self.user?["authToken"] = Twitter.sharedInstance().sessionStore.session()!.authToken
        self.twitterCompletionHandler!(self.user , nil)
    }
}
