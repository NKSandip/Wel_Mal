//
//  HistoryJobsList+Services.swift
//  OnDemandApp
//
//  Created by Pawan Dhawan on 22/08/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation

// MARK: - ### API Handling ###

extension Job {
    
    
    // MARK:- Open Job Webservices
    
    // Fetch open job list
    class func getOpenJobsList(_ page: Int, _ requestId:Int, completion: @escaping (_ openJobsList: AnyObject? ,_ success: Bool, _ error: NSError?) -> (Void)) {
        let requestIdString = String(requestId)
        let val = ["serviceRequestId":requestIdString]
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET , urlString: Constants.APIServiceMethods.getOpenJobsAPI + String(page), params: val as [String : AnyObject]?) { (response) -> Void in
            
            print("Response = %@",response.resultDictionary)
            self.handleApiResponseForOpenJobsList(response, completion: completion)
        }
    }
    
    /**
     Method used to handle api response and based on the status it calls completion handler
     
     - parameter response:   api response
     - parameter completion: completion handler
     */
    class func handleApiResponseForOpenJobsList( _ response: Response, completion: (_ openJobsList: AnyObject?, _ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response.resultDictionary)")
        if response.success {
            if let jobDict = response.resultDictionary?.value(forKeyPath: "details") {
                
                let job: Job = ModelMapper<Job>.map(jobDict as! [String : AnyObject])!
                if let _ = (jobDict as AnyObject).value(forKeyPath: "associateWorkers") {
                    if(job.associateWorkers != nil) {
                        var associateWorkers = [JobBidMember]()
                        for workersDict in  (jobDict as AnyObject).value(forKeyPath: "associateWorkers") as! [AnyObject] {
                            let associateWorker = ModelMapper<JobBidMember>.map(workersDict as! [String : AnyObject])!
                            associateWorkers.append(associateWorker)
                        }

                        job.associateWorkers = associateWorkers
                    
                        
                    }
                }
                if let _ = (jobDict as AnyObject).value(forKeyPath: "serviceDocument") {
                    if job.serviceDocument != nil {
                        var docLists = [Document]()
                        for list in  (jobDict as AnyObject).value(forKeyPath: "serviceDocument") as! [AnyObject] {
                            let docList: Document = ModelMapper<Document>.map(list as! [String : AnyObject])!
                            docLists.append(docList)
                        }
                        job.serviceDocument = docLists
                    }
                }
                if let _ = (jobDict as AnyObject).value(forKeyPath: "tags") {
                if job.tags != nil {
                    
                    var serviceTypes = [AnyObject]()
                    var text = ""
                    var serviceTypeId = ""
                    
                    for serviceTypeDict in job.tags! {
                        
                        let serviceType: E3malServiceType = ModelMapper<E3malServiceType>.map(serviceTypeDict as! [String : AnyObject])!
                        serviceType.isSelected = false
                        serviceTypes.append(serviceType)
                        text = text.appending("#\((serviceType.serviceName)!) ")
                        serviceTypeId = serviceTypeId.appending("\((serviceType.serviceTypeId)!),")
                        
                    }
                    job.tags = serviceTypes
                    job.tagNames = text
                    job.tagIds = serviceTypeId
                  }
                }
                if let _ = (jobDict as AnyObject).value(forKeyPath: "seviceCategory") {
                    if job.seviceCategory != nil  {
                        for category in job.seviceCategory! {
                            let category: E3malCategory = ModelMapper<E3malCategory>.map(category as! [String : AnyObject])!
                            job.categoryName = category.name
                            job.selectedCategoryId = category.jobTypeId

                        }
                        
                    }
                    
                }
                
                completion(job,true, nil)
            }
            else {
                completion(nil, false, response.responseError)
            }
            
        }
        else
        {
            completion(nil, false, response.responseError)
        }
    }
    
    
    // Accept Job API
    func acceptJob(_ jobId: Int, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let params = ["jobId" : jobId] as NSDictionary
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST , urlString: Constants.APIServiceMethods.acceptJob, params: params as? [String : AnyObject]) { (response) -> Void in
            self.handleApiResponseAcceptJob(response, completion: completion)
        }
    }
    
    
    // Handling response for Accept Job API
    
    func handleApiResponseAcceptJob(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response.resultDictionary)")
        
        if response.success {
            if let _ = response.resultDictionary?.value(forKeyPath: "message") {
                completion(true, nil)
            } else {
                completion(false, response.responseError)
            }
        }
        else
        {
            if(response.resultDictionary?.value(forKeyPath: "message") != nil ) {
                self.showAlertViewWithMessage(response.resultDictionary?.value(forKeyPath: "message") as! String, message: "")
            }
            completion(false, response.responseError)
        }
    }
    
    
    // Alert message
    
    func showAlertViewWithMessage(_ title: String, message: String) {
        
        let alertController = UIAlertController(title: title, message: message, preferredStyle: UIAlertControllerStyle.alert)
        let alAction = UIAlertAction(title: NSLocalizedString("OK", comment: "OK"), style: .default) { (action) in
            
        }
        alertController.addAction(alAction)
        AppDelegate.delegate().window?.viewController()?.present(alertController, animated: true, completion: nil)
    }
    
    
    // MARK:- My Job Webservices
    
    
    // Get My Job List
    class func myjobsforpage( _ page:Int, completion: @escaping (_ page : Int, _ jobList: [AnyObject]?, _ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug(Constants.APIServiceMethods.getMyJobsAPI + String(page))
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET , urlString: Constants.APIServiceMethods.getMyJobsAPI + String(page), params: nil) { (response) -> Void in
            
            self.handleApiResponseForMyJobsList(response, completion: completion)
        }
    }
    
    // Get My Job List
    class func myjobsforpage( _ page:Int, listType:Int, completion: @escaping (_ page : Int, _ jobList: [AnyObject]?, _ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug(Constants.APIServiceMethods.getMyJobsAPI + String(page))
        let param = ["listType":"\(listType)"]
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET , urlString: Constants.APIServiceMethods.getMyJobsAPI + String(page), params: param as [String : AnyObject]?) { (response) -> Void in
            
            self.handleApiResponseForMyJobsList(response, completion: completion)
        }
    }
    
    // Get My Job List
    class func myjobsforpageSearch( _ page:Int, tagId:String, completion: @escaping (_ page : Int, _ jobList: [AnyObject]?, _ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug(Constants.APIServiceMethods.getMyJobsAPI + String(page))
        let param = ["tagId":tagId]
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET , urlString: Constants.APIServiceMethods.getMyJobsAPI + String(page), params: param as [String : AnyObject]?) { (response) -> Void in
            
            self.handleApiResponseForMyJobsList(response, completion: completion)
        }
    }
    
    // Get My Job List
    class func myjobsforPageAndPendingList( _ page:Int, completion: @escaping (_ page : Int, _ jobList: [AnyObject]?, _ pendingFeedbackList: [AnyObject]?, _ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug(Constants.APIServiceMethods.getMyJobsAPI + String(page))
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET , urlString: Constants.APIServiceMethods.getMyJobsAPI + String(page), params: nil) { (response) -> Void in
            
            self.handleApiResponseForMyJobsListANdPendingFeedbackList(response, completion: completion)
        }
    }
    
    
    /**
     Method used to handle api response and based on the status it calls completion handler
     
     - parameter response:   api response
     - parameter completion: completion handler
     */
    class func handleApiResponseForMyJobsList(_ response: Response, completion: (_ page : Int, _ jobList: [AnyObject]?, _ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response.resultDictionary)")
        if response.success {
            if let _ = response.resultDictionary?.value(forKeyPath: "jobList") {
                
                var jobArr = [AnyObject]()
                for jobDict in response.resultDictionary?.value(forKeyPath: "jobList") as! [AnyObject] {
                    let job: Job = ModelMapper<Job>.map(jobDict as! [String : AnyObject])!
                    if let desc = jobDict.value(forKey: "description"){
                        job.jobDescription = desc as? String
                    }
                    if job.tags != nil {
                        
                        var serviceTypes = [AnyObject]()
                        var text = ""
                        var serviceTypeId = ""
                        
                        for serviceTypeDict in job.tags! {
                            
                            let serviceType: E3malServiceType = ModelMapper<E3malServiceType>.map(serviceTypeDict as! [String : AnyObject])!
                            serviceType.isSelected = false
                            serviceTypes.append(serviceType)
                            text = text.appending("#\((serviceType.serviceName)!) ")
                            serviceTypeId = serviceTypeId.appending("\((serviceType.serviceTypeId)!),")
                            
                        }
                        job.tags = serviceTypes
                        job.tagNames = text
                        job.tagIds = serviceTypeId
                    }
                    
                    if job.myBid != nil {
                        
                        let bid: Bid = ModelMapper<Bid>.map(job.myBid as! [String : AnyObject])!
                        if let _ = (bid as AnyObject).value(forKeyPath: "documents") {
                            if bid.documents != nil {
                                var docLists = [Document]()
                                for list in  (bid as AnyObject).value(forKeyPath: "documents") as! [AnyObject] {
                                    let docList: Document = ModelMapper<Document>.map(list as! [String : AnyObject])!
                                    docLists.append(docList)
                                }
                                bid.documents = docLists
                            }
                        }
                        
                        if let _ = (bid as AnyObject).value(forKeyPath: "dispute") {
                            if bid.dispute != nil {
                                let dispute: Dispute = ModelMapper<Dispute>.map(bid.dispute as! [String : AnyObject])!
                                bid.dispute = dispute
                            }
                        }
                        
                        job.myBid = bid
                    }
                    
                    
                    
                    jobArr.append(job)
                }
                
                // let jobArr = ModelMapper<Job>.mapArray(response.resultDictionary?.value(forKeyPath: "jobList"))
                
                completion(Int((response.resultDictionary?.value(forKeyPath: "page")) as! String)!, jobArr, true, nil)
            }
            else {
                completion(-1, nil, false, response.responseError)
            }
            
        }
        else
        {
            completion(-1, nil, false, response.responseError)
        }
    }
    
    class func handleApiResponseForMyJobsListANdPendingFeedbackList(_ response: Response, completion: (_ page : Int, _ jobList: [AnyObject]?, _ pendingFeedbackList: [AnyObject]?, _ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response.resultDictionary)")
        if response.success {
            if let _ = response.resultDictionary?.value(forKeyPath: "jobList") {
                
                var jobArr = [AnyObject]()
                for jobDict in response.resultDictionary?.value(forKeyPath: "jobList") as! [AnyObject] {
                    let job: Job = ModelMapper<Job>.map(jobDict as! [String : AnyObject])!
                    if let desc = jobDict.value(forKey: "description"){
                        job.jobDescription = desc as? String
                    }
                    if job.tags != nil {
                        
                        var serviceTypes = [AnyObject]()
                        var text = ""
                        var serviceTypeId = ""
                        
                        for serviceTypeDict in job.tags! {
                            
                            let serviceType: E3malServiceType = ModelMapper<E3malServiceType>.map(serviceTypeDict as! [String : AnyObject])!
                            serviceType.isSelected = false
                            serviceTypes.append(serviceType)
                            text = text.appending("#\((serviceType.serviceName)!) ")
                            serviceTypeId = serviceTypeId.appending("\((serviceType.serviceTypeId)!),")
                            
                        }
                        job.tags = serviceTypes
                        job.tagNames = text
                        job.tagIds = serviceTypeId
                    }
                    
                    if job.myBid != nil && job.myBid != ("<null>" as AnyObject as! _OptionalNilComparisonType)  {
                        
                        let bid: Bid = ModelMapper<Bid>.map(job.myBid as! [String : AnyObject])!
                        job.myBid = bid
                    }
                    
                    
                    
                    jobArr.append(job)
                }
                
                // let jobArr = ModelMapper<Job>.mapArray(response.resultDictionary?.value(forKeyPath: "jobList"))
                
                var feedbacks = [AnyObject]()
                
                if let _ = response.resultDictionary?.value(forKeyPath: "pendingList"){
                
                    LogManager.logDebug("\(response.resultDictionary?.value(forKeyPath: "pendingList"))")
                    for feedbackDict in response.resultDictionary?.value(forKeyPath: "pendingList") as! [AnyObject] {
                        let feedback: Feedback = ModelMapper<Feedback>.map(feedbackDict as! [String : AnyObject])!
                        feedbacks.append(feedback)
                        
                    }
                }
                
                completion(Int((response.resultDictionary?.value(forKeyPath: "page")) as! String)!, jobArr, feedbacks, true, nil)
            }
            else {
                completion(-1, nil, nil, false, response.responseError)
            }
            
        }
        else
        {
            completion(-1, nil, nil, false, response.responseError)
        }
    }
    
    
    func getTagsNames(tagsDict : [AnyObject]) -> String {
        
        var text = ""
        for dict in tagsDict {
            if let serviceName = dict.value(forKey: "serviceName"){
                text = text.appending("#\(serviceName) ")
            }
        }
        return text
    }
    
    // Cancel jobs
    
    func cancelJob(_ jobId: Int, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let params = ["jobId" : jobId] as NSDictionary
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST , urlString: Constants.APIServiceMethods.cancelJob, params: params as? [String : AnyObject]) { (response) -> Void in
            self.handleApiResponseCancelJob(response, completion: completion)
        }
    }
    
    
    // Handling response for complete and cancel job
    
    func handleApiResponseCancelJob(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response.resultDictionary)")
        
        if response.success {
            if let _ = response.resultDictionary?.value(forKeyPath: "message") {
                completion(true, nil)
            } else {
                completion(false, response.responseError)
            }
        }
        else
        {
            if(response.resultDictionary?.value(forKeyPath: "message") != nil ) {
                self.showAlertViewWithMessage(response.resultDictionary?.value(forKeyPath: "message") as! String, message: "")
            }
            completion(false, response.responseError)
        }
    }
    
    
    
    // Completed jobs
    
    func completeJob(_ jobId: Int, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let params = ["jobId" : jobId] as NSDictionary
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST , urlString: Constants.APIServiceMethods.completeJob, params: params as? [String : AnyObject]) { (response) -> Void in
            self.handleApiResponseCompleteJob(response, completion: completion)
        }
    }
    
    // Handling response for completed job
    
    func handleApiResponseCompleteJob(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response.resultDictionary)")
        
        if response.success {
            if let _ = response.resultDictionary?.value(forKeyPath: "message") {
                completion(true, nil)
            } else {
                completion(false, response.responseError)
            }
        }
        else
        {
            if(response.resultDictionary?.value(forKeyPath: "message") != nil ) {
                self.showAlertViewWithMessage(response.resultDictionary?.value(forKeyPath: "message") as! String, message: "")
            }
            completion(false, response.responseError)
        }
    }
    
    
    // MARK: Job History Webservices
    
    // Fetch Job History
    class func getHistoryJobsList( _ page:Int, completion: @escaping (_ page : Int,_ jobHistoryList: [AnyObject]?, _ success: Bool, _ error: NSError?) -> (Void)) {
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET , urlString: Constants.APIServiceMethods.getHistoryJobsAPI + String(page), params: nil) { (response) -> Void in
            
            self.handleApiResponseForHistoryJobsList(response, completion: completion)
        }
    }
    
    /**
     Method used to handle api response and based on the status it calls completion handler
     
     - parameter response:   api response
     - parameter completion: completion handler
     */
    class func handleApiResponseForHistoryJobsList(_ response: Response, completion: (_ page : Int, _ jobHistoryList: [AnyObject]?, _ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response.resultDictionary)")
        if response.success {
            if let _ = response.resultDictionary?.value(forKeyPath: "jobList") {
                //let jobArr = ModelMapper<Job>.mapArray(response.resultDictionary?.value(forKeyPath: "jobList"))
                
                var jobArr = [AnyObject]()
                for jobDict in response.resultDictionary?.value(forKeyPath: "jobList") as! [AnyObject] {
                    let job: Job = ModelMapper<Job>.map(jobDict as! [String : AnyObject])!
                    jobArr.append(job)
                }
                
                completion(Int((response.resultDictionary?.value(forKeyPath: "page")) as! String)!, jobArr, true, nil)
            }
            else {
                completion(-1, nil, false, response.responseError)
            }
            
        }
        else
        {
            completion(-1, nil, false, response.responseError)
        }
    }
    
    
    //MARK: POST Job API
    class func postJobRequest(param : [String:Any], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.postJob,params: param as [String : Any]? as [String : AnyObject]?) { (response) in
            self.handlePostJobResponse(response, completion: completion)
        }
    }
    
    class func handlePostJobResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        LogManager.logDebug("response = \(response)")
        
        if response.success {
            completion(true, nil)
        } else {
            completion(false, response.responseError)
        }
    }
    
    class func updateJobRequest(param : [String:Any], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.updateJob,params: param as [String : Any]? as [String : AnyObject]?) { (response) in
            self.handlePostJobResponse(response, completion: completion)
        }
    }
    
    
    //MARK: BID Job API
    class func bidJobRequest(param : [String:Any], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.bidJob,params: param as [String : Any]? as [String : AnyObject]?) { (response) in
            self.handleBidJobResponse(response, completion: completion)
        }
    }
    
    class func handleBidJobResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        if response.success {
            LogManager.logDebug("\(response.resultDictionary)")
            if let _ = response.resultDictionary?.value(forKeyPath: "message") {
                completion(true, nil)
            } else {
                completion(false, response.responseError)
            }
        }
        else
        {
            completion(false, response.responseError)
        }
    }
    
    
    //MARK: BID Job API
    class func completeJobRequest(param : [String:Any], completion: @escaping (_ success: Bool, _ error: NSError?, _ serviceFeedbackId:String?) -> (Void)) {
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.completeJob,params: param as [String : Any]? as [String : AnyObject]?) { (response) in
            self.handleCompleteJobRequest(response, completion: completion)
        }
    }
    
    class func handleCompleteJobRequest(_ response: Response, completion: (_ success: Bool, _ error: NSError?, _ serviceFeedbackId:String? ) -> (Void)) {
        if response.success {
            LogManager.logDebug("\(response.resultDictionary)")
            if let _ = response.resultDictionary?.value(forKeyPath: "message") {
                if let _ = response.resultDictionary?.value(forKeyPath: "serviceFeedbackId") {
                    let feedbackId = "\((response.resultDictionary?.value(forKeyPath: "serviceFeedbackId"))!)"
                    completion(true, nil, feedbackId)
                }else{
                    completion(true, nil, nil)
                }
                
                
            } else {
                completion(false, response.responseError, nil)
            }
        }
        else
        {
            completion(false, response.responseError, nil)
        }
    }
    
    //MARK: BID Job API
    class func cancelMyBidRequest(param : [String:Any], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.cancelMyBid,params: param as [String : Any]? as [String : AnyObject]?) { (response) in
            self.handleCancelMyBidRequest(response, completion: completion)
        }
    }
    
    class func handleCancelMyBidRequest(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        if response.success {
            LogManager.logDebug("\(response.resultDictionary)")
            if let _ = response.resultDictionary?.value(forKeyPath: "message") {
                completion(true, nil)
            } else {
                completion(false, response.responseError)
            }
        }
        else
        {
            completion(false, response.responseError)
        }
    }
    
    
    //MARK: BID Job API
    class func declineJobRequest(param : [String:Any], completion: @escaping (_ success: Bool, _ error: NSError?, _ feedbackId: String?) -> (Void)) {
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.cancelJob,params: param as [String : Any]? as [String : AnyObject]?) { (response) in
            self.handleDeclineJobRequest(response, completion: completion)
        }
    }
    
    class func handleDeclineJobRequest(_ response: Response, completion: (_ success: Bool, _ error: NSError?, _ feedbackId: String?) -> (Void)) {
        if response.success {
            LogManager.logDebug("\(response.resultDictionary)")
            if let _ = response.resultDictionary?.value(forKeyPath: "message") {
                if let _ = response.resultDictionary?.value(forKeyPath: "serviceFeedbackId") {
                    let feedbackId = "\((response.resultDictionary?.value(forKeyPath: "serviceFeedbackId"))!)"
                    completion(true, nil, feedbackId)
                }else{
                    completion(true, nil, nil)
                }
                
                
            } else {
                completion(false, response.responseError, nil)
            }
        }
        else
        {
            completion(false, response.responseError, nil)
        }
    }
    
    
    class func adminBankDetailRequest(completion: @escaping (_ bankDetail: AnyObject?,_ success: Bool, _ error: NSError?) -> (Void)) {
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET, urlString: Constants.APIServiceMethods.adminBankDetail,params: nil) { (response) in
            self.adminBankDetailResponse(response, completion: completion)
        }
    }
    
    class func adminBankDetailResponse(_ response: Response, completion: (_ bankDetail: AnyObject?,_ success: Bool, _ error: NSError?) -> (Void)) {
        if response.success {
            LogManager.logDebug("\(response.resultDictionary)")
            if let jobDict = response.resultDictionary?.value(forKeyPath: "details") {
                let bankDetail: AdminBankDetail = ModelMapper<AdminBankDetail>.map(jobDict as! [String : AnyObject])!
                completion(bankDetail,true, nil)
            } else {
                completion(nil,false, response.responseError)
            }
        }
        else
        {
            completion(nil,false, response.responseError)
        }
    }
    
    class func acceptBidRequest(param : [String:Any], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.acceptBid,params: param as [String : Any]? as [String : AnyObject]?) { (response) in
            self.handleAPIResponse(response, completion: completion)
        }
    }
    
    class func handleAPIResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response)")
        
        if response.success {
            completion(true, nil)
        } else {
            completion(false, response.responseError)
        }
    }
    
    class func hireCompleteJobRequest(param : [String:Any], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.hireCompleteJob,params: param as [String : Any]? as [String : AnyObject]?) { (response) in
            self.handleAPIResponse(response, completion: completion)
        }
    }
    
    
    class func deleteJobRequest(param : [String:Any], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.deleteJob,params: param as [String : Any]? as [String : AnyObject]?) { (response) in
            self.handleAPIResponse(response, completion: completion)
        }
    }
    
    
    
    // MARK: Get Job Detail
    class func getJobDetails( _ jobId:String, completion: @escaping (_ jobDetails: AnyObject?, _ message:String,  _ success: Bool, _ error: NSError?) -> (Void)) {
        let params:[String : String] = ["serviceRequestId" : jobId]
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET , urlString: Constants.APIServiceMethods.jobDetailAPI, params: params as [String : AnyObject]?) { (response) -> Void in
            
            self.handleApiResponseForGetJobDetails(response, completion: completion)
        }
    }
    
    /**
     Method used to handle api response and based on the status it calls completion handler
     
     - parameter response:   api response
     - parameter completion: completion handler
     */
    
    class func handleApiResponseForGetJobDetails(_ response: Response, completion: (_ jobDetails: AnyObject?, _ message:String, _ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response.resultDictionary)")
        if response.success {
            if let jobDetails = response.resultDictionary?.value(forKeyPath: "details") {
                let job: Job = ModelMapper<Job>.map(jobDetails as! [String : AnyObject])!
                
                
                if let desc = (jobDetails as AnyObject).value(forKey: "description"){
                    job.jobDescription = desc as? String
                }
                if job.tags != nil {
                    
                    var serviceTypes = [AnyObject]()
                    var text = ""
                    var serviceTypeId = ""
                    
                    for serviceTypeDict in job.tags! {
                        
                        let serviceType: E3malServiceType = ModelMapper<E3malServiceType>.map(serviceTypeDict as! [String : AnyObject])!
                        serviceType.isSelected = false
                        serviceTypes.append(serviceType)
                        text = text.appending("#\((serviceType.serviceName)!) ")
                        serviceTypeId = serviceTypeId.appending("\((serviceType.serviceTypeId)!),")
                        
                    }
                    job.tags = serviceTypes
                    job.tagNames = text
                    job.tagIds = serviceTypeId
                }
                
                if job.myBid != nil {
                    
                    let bid: Bid = ModelMapper<Bid>.map(job.myBid as! [String : AnyObject])!
                    if let _ = (bid as AnyObject).value(forKeyPath: "documents") {
                        if bid.documents != nil {
                            var docLists = [Document]()
                            for list in  (bid as AnyObject).value(forKeyPath: "documents") as! [AnyObject] {
                                let docList: Document = ModelMapper<Document>.map(list as! [String : AnyObject])!
                                docLists.append(docList)
                            }
                            bid.documents = docLists
                        }
                    }
                    
                    if let _ = (bid as AnyObject).value(forKeyPath: "dispute") {
                        if bid.dispute != nil {
                            let dispute: Dispute = ModelMapper<Dispute>.map(bid.dispute as! [String : AnyObject])!
                            bid.dispute = dispute
                        }
                    }
                    
                    job.myBid = bid
                }
                
                
                
                completion(job, "", true, nil)
            }
            else {
                completion(nil, response.message(), false, response.responseError)
            }
        }
        else
        {
            completion(nil, "", false, response.responseError)
        }
    }
    
    
}
