//
//  Category.swift
//  OnDemandApp
//
//  Created by Shwetabh Singh on 19/08/16.
//  Copyright © 2016 Appster. All rights reserved.
//



import UIKit

enum JobStatus : Int {
    case pending = 1
    case underProcess = 2
    case completed = 3
    case canceled = 4   // canceledBySeeker in case of History
    case canceledByProvider = 5
}

enum JobDetailType : Int {
    case openJobs = 1
    case myJobs = 2
    case historyJobs = 3
}

class Job: Model {
    
    var assignedUserId : NSNumber?
    var calculatedPrice : NSNumber?
    var createdAt : String?
    var canceledAt : String?
    var distanceCovered : NSNumber?
    var endLocationAddress : String?
    var endLocationLatitude : String?
    var endLocationLongitude : String?
    var id : NSNumber?
    var jobId : NSNumber?
    var jobName : String?
    var name: String?
    var jobServiceTypeId : NSNumber?
    var jobStatus : NSNumber?
    var jobTypeId : NSNumber?
    var jobType : NSNumber?
    var proposedPrice : NSNumber?
    var providerName : String?
    var serviceDateTime : String?
    var serviceEndTime : String?
    var serviceName : String?
    var serviceStartTime : String?
    var startLocationAddress : String?
    var startLocationLatitude : String?
    var startLocationLongitude : String?
    var userId : NSNumber!
    var userServiceId : NSNumber?
    var paidPrice : NSNumber?
    
    var seekerName : String? // for provider my jobs, open jobs, and history
    
    var biddingEndDate : String?
    var posterName : String?
    var posterProfileImage : String?
    var priceMax : NSNumber?
    var priceMin : NSNumber?

    var title : String?
    var cityName : String?
    var cityId: NSNumber?
    var countryName: String?
    var countryId: NSNumber?
    var moneyDeposite : NSNumber?
    var jobDescription : String?
    var bidderCount: NSNumber?
    var profileImage : String?
    var associateWorkers: [JobBidMember]?
    var membersApplied:NSNumber?
    var tags : [AnyObject]?
    var tagNames : String?
    var tagIds : String?
    var categoryName : String?
    var selectedCategoryId: NSNumber?
    var myBid : AnyObject?
    var serviceDocument : [Document]?
    var seviceCategory : [AnyObject]?
    var totalFeedbackPoint: NSNumber?
    var totalFeedbackUser: NSNumber?
    var providerFeedbackPoint : NSNumber?
    var seekerFeedbackPoint: NSNumber?
    var tab: NSNumber?
    var isProfileVerified:NSNumber?
  

}

class Bid:Model{
    /*acceptanceDatetime = "0000-00-00 00:00:00";
     acceptanceEndDate = "0000-00-00";
     acceptancePrice = 0;
     acceptanceStatus = 1;
     canceledAt = "<null>";
     coverText = "HI Hasib";
     createdAt = "2016-12-13 13:08:56";
     document = "";
     endTime = "2017-01-15 00:00:00";
     id = 42;
     price = 2300;
     providerId = 222;
     serviceRequestId = 59;*/
    var id : NSNumber?
    var endTime : String?
    var price : NSNumber?
    var coverText : String?
    var documents: [Document]?
    var providerFeedbackPoint : NSNumber?
    var seekerFeedbackPoint: NSNumber?
    var dispute : AnyObject?
    var createdAt: String?
    
    
  
}

class Dispute:Model{
    
    var adminComment : String?
    var adminCommentDate : String?
    var createdAt : String?
    var deletedAt : String?
    var id: NSNumber?
    var providerComment : String?
    var providerCommentDate: String?
    var seekerComment : String?
    var seekerCommentDate : String?
    var serviceRequestId: NSNumber?
    var updatedAt : String?

}
