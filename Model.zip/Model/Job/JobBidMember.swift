//
//  JobBidMember.swift
//  E3malApp
//
//  Created by Rishav Tomar on 29/11/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import UIKit

class JobBidMember: Model {
    
    var id: NSNumber?
    var serviceRequestId: NSNumber?
    var providerId: NSNumber?
    var acceptancePrice: NSNumber?
    var price: NSNumber?
    var endTime: String?
    var coverText: String?
    var document: String?
    var acceptanceStatus: NSNumber?
    var acceptanceDatetime: String?
    var acceptanceEndDate: String?
    var createdAt: String?
    var updatedAt: String?
    var deletedAt: String?
    var canceledAt: String?
    var name: String?
    var countryName: String?
    var cityName: String?
    var profileImage: String?
    var totalFeedbackPoint: NSNumber?
    var totalFeedbackUser: NSNumber?
    var isProfileVerified:NSNumber?
    var isMore = NSNumber(value: false)
}
