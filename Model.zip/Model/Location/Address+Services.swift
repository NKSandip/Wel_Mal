//
//  Address+Services.swift
//  MapSample
//
//  Created by Arvind Singh on 10/09/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation
import MapKit

extension Address {
    
    //"http://maps.googleapis.com/maps/api/geocode/json?address=%@"
    //"http://maps.googleapis.com/maps/api/geocode/json?address=%f,%f"
    
    // MARK: Reverse geocodes a coordinate on the Earth's surface.
    /**
     Find geocode coordinate for an address.
     
     - parameter address: Complete address string
     - parameter handler: The callback to invoke with the geocode results.
     */
    class func findGeocodeForAddress(_ address: String, completionHandler handler: @escaping (_ address: Address?, _ error: Error?) -> (Void)) {
        
        let params = ["address": address]//, "key": "AIzaSyATPR9G3mo-eEkdHyV-_ckWHvh5StCckyk"]
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET, urlString: "https://maps.googleapis.com/maps/api/geocode/json", params: params as [String : AnyObject]?) { (response) -> Void in
            
            if response.success {
                
                let address: Address = Address.init(address: "", coordinate: kCLLocationCoordinate2DInvalid)
                
                if let results: NSMutableArray = response.resultDictionary?.object(forKey: "results") as? NSMutableArray , results.count > 0 {
                    
                    if let dictionary = results.firstObject as? NSDictionary {
                        if let formattedAddress = dictionary["formatted_address"] as? String {
                            address.formattedAddress = formattedAddress
                        }

                        if let geometryDictionary = dictionary["geometry"] as? NSDictionary {
                            let latitude = ((geometryDictionary.object(forKey: "location") as AnyObject).object(forKey: "lat") as AnyObject).doubleValue
                            let longitude = ((geometryDictionary.object(forKey: "location") as AnyObject).object(forKey: "lng") as AnyObject).doubleValue

                            let coordinate: CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude!, longitude!)
                            address.coordinate = coordinate
                        }
                    }
                }
                
                handler(address, nil)
            } else {
                handler(nil, response.responseError)
            }
        }
    }
    
    
    
    /**
     Reverse geocodes a coordinate on the Earth's surface.
     
     - parameter coordinate: Geographical coordinate
     - parameter handler: The callback to invoke with the reverse geocode results.
     */
    class func reverseGeocodeCoordinate(_ coordinate: CLLocationCoordinate2D, completionHandler handler: @escaping (_ address: Address?, _ error: NSError?) -> (Void)) {
        
        let params = ["latlng": String(format: "%f,%f", coordinate.latitude, coordinate.longitude)]//, "key": "AIzaSyATPR9G3mo-eEkdHyV-_ckWHvh5StCckyk"]
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET, urlString: "https://maps.googleapis.com/maps/api/geocode/json", params: params as [String : AnyObject]?) { (response) -> Void in
            
            if response.success {
                
                let address: Address = Address.init(address: "", coordinate: kCLLocationCoordinate2DInvalid)
                
                if let results: NSMutableArray = response.resultDictionary?.object(forKey: "results") as? NSMutableArray , results.count > 0 {
                    
                    if let dictionary = results.firstObject as? NSDictionary {
                        if let formattedAddress = dictionary["formatted_address"] as? String {
                            address.formattedAddress = formattedAddress
                        }

                        if let geometryDictionary = dictionary["geometry"] as? NSDictionary {
                            let latitude = ((geometryDictionary.object(forKey: "location") as AnyObject).object(forKey: "lat") as AnyObject).doubleValue
                            let longitude = ((geometryDictionary.object(forKey: "location") as AnyObject).object(forKey: "lng") as AnyObject).doubleValue

                            let coordinate: CLLocationCoordinate2D = CLLocationCoordinate2DMake(latitude!, longitude!)
                            address.coordinate = coordinate
                        }
                    }
                }
                
                handler(address, nil)
            } else {
                handler(nil, response.responseError)
            }
        }
    }
}
