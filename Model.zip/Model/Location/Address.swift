//
//  Address.swift
//  MapSample
//
//  Created by Arvind Singh on 10/09/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation
import MapKit

class Address {
    var coordinate: CLLocationCoordinate2D!
    var formattedAddress: String!
    
    init(address: String, coordinate: CLLocationCoordinate2D) {
        self.formattedAddress = address
        self.coordinate = coordinate
    }
}