//
//  MapPinAnnotation.swift
//  MapSample
//
//  Created by Arvind Singh on 10/09/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation
import MapKit

class MapPinAnnotation : NSObject, MKAnnotation {

    //var coordinate: CLLocationCoordinate2D
    
    var latitude: Double = 0.0
    var longitude: Double = 0.0
    
    var coordinate: CLLocationCoordinate2D {
        set {
            self.latitude = newValue.latitude
            self.longitude = newValue.longitude
        }
        get {
            return CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        }
    }
    
    var title: String?
    var subtitle: String?


    init(locationCoordinate: CLLocationCoordinate2D, title: String, subtitle: String) {
        super.init()

        self.latitude = 0.0
        self.longitude = 0.0
        self.coordinate = locationCoordinate
        self.title = title
        self.subtitle = subtitle
    }
}