//
//  User+Services.swift
//  OnDemandApp
//  Created by Sourabh Bhardwaj on 07/04/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import Foundation

// MARK: - ### API Handling ###
extension User {
    
    
    // MARK: Upload user profile photo
    func uploadUserPhoto(_ profileImage: UIImage, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        var fileParams = [String: AnyObject]()
        fileParams["key"] = "profileImage" as AnyObject?
        fileParams["fileName"] = "userImage.jpg" as AnyObject?
        fileParams["value"] = UIImageJPEGRepresentation(profileImage, 0.2) as AnyObject?
        fileParams["contentType"] = "image/jpeg" as AnyObject?
        
        let request: NSMutableURLRequest = NSMutableURLRequest(url: URL(string: Constants.APIServiceMethods.updateProfileImage)!)
        request.setMultipartFormData(nil, fileFields: [fileParams])
        
        RequestManager.sharedManager().performRequest(request, userInfo: nil) { (response) -> Void in
            
            handleApiResponse(response, completion: completion)
        }
    }
    
    

    
    // MARK: Change user password
    
    
    func changePassword(_ oldPassword : String,newPassword : String,confirmPassword : String, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let parameters = ["oldPassword" : oldPassword, "newPassword" : newPassword,"confirmPassword" : confirmPassword]

        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.changePasswordAPI, params: parameters as [String : AnyObject]?) { (response) -> Void in
            
            handleApiResponse(response, completion: completion)
        }
    }
    
    func bankDetail(_ bankName: String,accountName : String, iban : String, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let user = UserManager.sharedManager().activeUser
        let parameters = ["bankName" : bankName, "bankAccountName" : accountName,"iban" : iban,"roleType" : user?.roleType as! Int] as [String : Any]
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.bankDetailAPI, params: parameters as [String : AnyObject]?) { (response) -> Void in
            
            handleApiResponse(response, completion: completion)
        }
    }
    
    func update(category: String, tags: String) {
        delegate?.update(category: category, tags: tags)
    }
    
    func updateProfile() {
        updateProfileDelegate?.updateUserProfile()
    }
    
}
