//
//  User.swift
//  OnDemandApp
//  Created by Sourabh Bhardwaj on 01/04/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import UIKit

class User: Model, NSCoding {
    
    //TODO: remove id variable
    
    var delegate:APUpdatedCategoryAndTags?
    var updateProfileDelegate : APUpdateProfile?
    
    var accessToken : String?
    var userId: NSNumber!
    var name: String!
    var email: String!
    var googlePlusId: String?
    
    var profileImage: String?
    var permanentCountryId: NSNumber?
    var permanentStateId: NSNumber?
    var permanentCityId: NSNumber?
    var permanentAddress: NSNumber?
    
    var permanentLatitude: String?
    var permanentLongitude: String?
    
    var roleType: NSNumber!
    var status: NSNumber!
    
    var isEmailVerified: NSNumber!
    var isPhoneVerified: NSNumber! 
    
    var isPushEnabled : NSNumber?
    var isCategorySaved: NSNumber? = 0
    var isServicesSaved: NSNumber? = 0
    var isSingleService: NSNumber? = 0
    
    
    var phone: String?
    var bankName: String?
    var accountNo: String?
    var bankBranch: String?
    var bankUsername: String?
    var hourlyRate: NSNumber?
    var ratingPoint: NSNumber?
    var totalUserRated: NSNumber?
    var totalJobPosted:NSNumber?
    // Properties for local usage. Not from login response. No need to store in NSUserDefaults.
    var otp: String?
    var userEditedCategories : [NSNumber]? // used to access selected category through multiple subcategory screen.
    var providerDetail : Provider?
    var successMessage = ""
    var biography: String?
    var dob: String?
    var id: NSNumber?
    var isOnboarded: NSNumber?
    var profileStatus: NSNumber?
    var unReadCount: NSNumber?
    var flagBankDetails: NSNumber?
    var isProfileVerified: NSNumber?
    var requestCount: NSNumber?
    var verifyNote: String?
    
    func fullName() -> String? {
        if let _ = name {
            return name
        }
        return nil
    }
    
    required init() {
        super.init()
    }
    
    // MARK: - NSCoding protocol methods
    required init?(coder aDecoder: NSCoder) {
        super.init()
        
        //Int(aDecoder.decodeObject(forKey: "isEmailVerified") as! String)! as NSNumber
        
        self.accessToken = aDecoder.decodeObject(forKey: "accessToken") as? String
        self.accountNo = aDecoder.decodeObject(forKey: "accountNo") as? String
        self.bankBranch = aDecoder.decodeObject(forKey: "bankBranch") as? String
        self.bankName = aDecoder.decodeObject(forKey: "bankName") as? String
        self.email = aDecoder.decodeObject(forKey: "email") as! String
        
        self.googlePlusId = aDecoder.decodeObject(forKey: "googlePlusId") as? String
        self.hourlyRate = aDecoder.decodeObject(forKey: "hourlyRate") as? NSNumber
        self.isEmailVerified = aDecoder.decodeObject(forKey: "isEmailVerified") as! NSNumber
        self.isPhoneVerified = aDecoder.decodeObject(forKey: "isPhoneVerified") as! NSNumber
        self.requestCount = aDecoder.decodeObject(forKey: "requestCount") as? NSNumber
        
        self.name = aDecoder.decodeObject(forKey: "name") as! String
        self.permanentAddress = aDecoder.decodeObject(forKey: "permanentAddress") as? NSNumber
        self.permanentCityId = aDecoder.decodeObject(forKey: "permanentCityId") as? NSNumber
        self.permanentCountryId = aDecoder.decodeObject(forKey: "permanentCountryId") as? NSNumber
        self.permanentLatitude = aDecoder.decodeObject(forKey: "permanentLatitude") as? String
        
        self.permanentLongitude = aDecoder.decodeObject(forKey: "permanentLongitude") as? String
        self.permanentStateId = aDecoder.decodeObject(forKey: "permanentStateId") as? NSNumber
        self.phone = aDecoder.decodeObject(forKey: "phone") as? String
        self.profileImage = aDecoder.decodeObject(forKey: "profileImage") as? String
        self.roleType = aDecoder.decodeObject(forKey: "roleType") as! NSNumber

        self.status = aDecoder.decodeObject(forKey: "status") as! NSNumber
        self.userId = aDecoder.decodeObject(forKey: "userID") as! NSNumber
        
        self.isServicesSaved = aDecoder.decodeObject(forKey: "isServicesSaved") as? NSNumber
        self.isSingleService = aDecoder.decodeObject(forKey: "isSingleService") as? NSNumber
        self.isCategorySaved = aDecoder.decodeObject(forKey: "isCategorySaved") as? NSNumber
        
        self.biography = aDecoder.decodeObject(forKey: "biography") as? String
        self.dob = aDecoder.decodeObject(forKey: "dob") as? String
        self.id = aDecoder.decodeObject(forKey: "id") as? NSNumber
        self.isOnboarded = aDecoder.decodeObject(forKey: "isOnboarded") as? NSNumber
        self.profileStatus = aDecoder.decodeObject(forKey: "profileStatus") as? NSNumber
        self.unReadCount = aDecoder.decodeObject(forKey: "unReadCount") as? NSNumber
        
        self.totalJobPosted = aDecoder.decodeObject(forKey: "totalJobPosted") as? NSNumber
        
        self.verifyNote = aDecoder.decodeObject(forKey: "verifyNote") as? String
    }
    
    func encode(with aCoder: NSCoder) {
        
        aCoder.encode(self.accessToken, forKey: "accessToken")
        
        aCoder.encode(self.userId, forKey: "userID")
        
        aCoder.encode(self.name, forKey: "name")
        aCoder.encode(self.email, forKey: "email")
        aCoder.encode(self.verifyNote, forKey: "verifyNote")
        
        aCoder.encode(self.googlePlusId, forKey: "googlePlusId")
        aCoder.encode(self.profileImage, forKey: "profileImage")
        aCoder.encode(self.permanentCountryId, forKey: "permanentCountryId")
        aCoder.encode(self.permanentStateId, forKey: "permanentStateId")
        aCoder.encode(self.permanentCityId, forKey: "permanentCityId")
        aCoder.encode(self.permanentAddress, forKey: "permanentAddress")
        aCoder.encode(self.roleType, forKey: "roleType")
        
        aCoder.encode(self.permanentLatitude, forKey: "permanentLatitude")
        aCoder.encode(self.permanentLongitude, forKey: "permanentLongitude")
        
        aCoder.encode(self.isEmailVerified, forKey: "isEmailVerified")
        aCoder.encode(self.isPhoneVerified, forKey: "isPhoneVerified")
        aCoder.encode(self.requestCount, forKey: "requestCount")
        
        aCoder.encode(self.phone, forKey: "phone")
        aCoder.encode(self.bankName, forKey: "bankName")
        aCoder.encode(self.accountNo, forKey: "accountNo")
        aCoder.encode(self.bankBranch, forKey: "bankBranch")
        aCoder.encode(self.hourlyRate, forKey: "hourlyRate")
        aCoder.encode(self.status, forKey: "status")
        
        aCoder.encode(self.isServicesSaved, forKey: "isServicesSaved")
        aCoder.encode(self.isCategorySaved, forKey: "isCategorySaved")
        aCoder.encode(self.isSingleService, forKey: "isSingleService")
        aCoder.encode(self.biography, forKey: "biography")
        aCoder.encode(self.dob, forKey: "dob")
        aCoder.encode(self.id, forKey: "id")
        aCoder.encode(self.isOnboarded, forKey: "isOnboarded")
        aCoder.encode(self.profileStatus, forKey: "profileStatus")
        aCoder.encode(self.unReadCount, forKey: "unReadCount")
        aCoder.encode(self.totalJobPosted, forKey: "totalJobPosted")

    }
}

