//
//  UserManager.swift
//  OnDemandApp
//  Created by Sourabh Bhardwaj on 01/04/16.
//  Copyright © 2016 Appster. All rights reserved.
//

import UIKit

let ACTIVE_USER_KEY = "activeUser"
let GUEST_USER_KEY = "guestUSer"
let LOGGED_USER_EMAIL_KEY_WORK = "userEmailWork"
let LOGGED_USER_PASSWORD_KEY_WORK = "userPasswordWork"

let LOGGED_USER_EMAIL_KEY_HIRE = "userEmailHire"
let LOGGED_USER_PASSWORD_KEY_HIRE = "userPasswordHire"

enum UserType : Int {
    case userTypeUnknown = 0
    case userTypeSeeker = 2
    case userTypeProvider = 3
}

/// User Manager - manages all feature for User model
class UserManager: NSObject {
    
    var userType: UserType {
        get {
            return UserType(rawValue: UserDefaults.standard.integer(forKey: "userType"))!
        }
        set {
            UserDefaults.standard.set(newValue.rawValue, forKey: "userType")
            UserDefaults.standard.synchronize()
        }
    }
    
    fileprivate var _activeUser: User?
    fileprivate var varificationToken: String?
    
    var activeUser: User! {
        get {
            return _activeUser
        }
        set {
            _activeUser = newValue
            if let _ = _activeUser {
                self.saveActiveUser()
            }
        }
    }
    
    deinit {
        
        if self.activeUser != nil {
            self.activeUser.removeObserver(self, forKeyPath: "unReadCount")
        }
        
        
    }
    
    
    // MARK: Singleton Instance
    fileprivate static let _sharedManager = UserManager()
    
    class func sharedManager() -> UserManager {
        return _sharedManager
    }
    
    fileprivate override init() {
        // initiate any queues / arrays / filepaths etc
        super.init()
        
        // Load last logged user data if exists
        if isUserLoggedIn() {
            loadActiveUser()
        }
    }
    
    func isUserLoggedIn() -> Bool {
        
        guard let _ = UserDefaults.objectForKey(ACTIVE_USER_KEY)
            else {
                return false
        }
        return true
    }
    
    func isGuestUser() -> Bool {
        guard let _ = UserDefaults.objectForKey(GUEST_USER_KEY)
            else {
                return false
        }
        return true
    }
    
    func userLogout() {
        
    }
    
    // MARK: - KeyChain / User Defaults / Flat file / XML
    
    /**
     Load last logged user data, if any
     */
    func loadActiveUser() {
        
        guard let decodedUser = UserDefaults.objectForKey(ACTIVE_USER_KEY) as? Data,
            let user = NSKeyedUnarchiver.unarchiveObject(with: decodedUser) as? User
            else {
                return
        }
        self.activeUser = user
    }
    
    func lastLoggedUserEmail(_ roleType : String) -> String? {
        
        if roleType == "2" {
            return UserDefaults.objectForKey(LOGGED_USER_EMAIL_KEY_HIRE) as? String
        }else{
            return UserDefaults.objectForKey(LOGGED_USER_EMAIL_KEY_WORK) as? String
        }
        
        
    }
    
    func lastLoggedUserPassword(_ roleType : String) -> String? {
        
        if roleType == "2" {
            return UserDefaults.objectForKey(LOGGED_USER_PASSWORD_KEY_HIRE) as? String
        }else{
            return UserDefaults.objectForKey(LOGGED_USER_PASSWORD_KEY_WORK) as? String
        }
    }
    
    
    
    
    /**
     Save current user data
     */
    func saveActiveUser() {
        
        UserDefaults.setObject(NSKeyedArchiver.archivedData(withRootObject: self.activeUser) as AnyObject?, forKey: ACTIVE_USER_KEY)
        
        if let email = self.activeUser.email {
            
            if self.activeUser.roleType == 2 {
            
                UserDefaults.setObject(email as AnyObject?, forKey: LOGGED_USER_EMAIL_KEY_HIRE)
                
            }else{
                
                UserDefaults.setObject(email as AnyObject?, forKey: LOGGED_USER_EMAIL_KEY_WORK)
            
            }
            
        }
    }
    
    /**
     Update current user data
     */
    func updateActiveUser() {
        saveActiveUser()
    }
    
    /**
     Delete current user data
     */
    func deleteActiveUser() {
        // remove active user from storage
        self.activeUser = nil
        UserDefaults.removeObjectForKey(ACTIVE_USER_KEY)
    }
    
    // used in api url's
    func userTypeString() -> String {
        
        if self.userType == .userTypeSeeker {
            return "user"
        } else if self.userType == .userTypeProvider {
            return "provider"
        } else {
            return "none"
        }
    }
    
    // used for api calls (paramaeters)
    func roleTypeString() -> (String) {
        if self.userType == .userTypeSeeker {
            return "2"
        } else if self.userType == .userTypeProvider {
            return "3"
        } else {
            return "0"
        }
    }
}


// MARK: API Services

extension UserManager {
    
    /**
     Method used to handle user signin and signup api response
     
     - parameter response:   api response
     - parameter completion: completion handler
     */
    func handleSignInSignUpResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response)")
        
        
        
        if response.success {
            // parse the response
            if let accessToken = response.resultDictionary?.value(forKeyPath: "accessToken") {
                
                LogManager.logDebug("\(response.resultDictionary)")
                if let userDictionary = response.resultDictionary?.value(forKeyPath: "user") {
                    let user: User = ModelMapper<User>.map(userDictionary as! [String : AnyObject])!
                    user.accessToken = accessToken as? String
                    user.flagBankDetails = user.profileStatus
                    self.activeUser = user
                    self.saveActiveUser()
                    completion(true, nil)
                } else {
                    completion(false, response.responseError)
                }
            }
            else
            {
                if let verificationToken = response.resultDictionary?.value(forKeyPath: "verificationToken") {
                    self.varificationToken = verificationToken as? String
                }
                
                completion(true, nil)
            }
        } else {
            completion(false, response.responseError)
        }
    }

    
    /**
     Method used to handle email already registered response
     
     - parameter response:   api response
     - parameter completion: completion handler
     */
    func handleCheckEmailResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        LogManager.logDebug("response = \(response)")
        
        if response.success {
            // parse the response
            completion(true, nil)
        
        } else {
            completion(false, response.responseError)
        }
    }
    
    /**
     Method used to handle user signin and signup api response
     
     - parameter response:   api response
     - parameter completion: completion handler
     */
    func handleUpdateProfileResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response)")
        
        if response.success {
            // parse the response
            if let userDictionary = response.resultDictionary?.value(forKeyPath: "user") {
                let user: User = ModelMapper<User>.map(userDictionary as! [String : AnyObject])!
                user.accessToken = self.activeUser.accessToken
                user.unReadCount = self.activeUser.unReadCount
                user.flagBankDetails = user.profileStatus
                self.activeUser = user
                self.saveActiveUser()
                completion(true, nil)
            } else {
                completion(true, nil)
            }
            
        } else {
            completion(false, response.responseError)
        }
    }
    
    
    /**
     Method used to handle user signin and signup api response
     
     - parameter response:   api response
     - parameter completion: completion handler
     */
    func handleUpdateProfileImageResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response)")
        
        if response.success {
            // parse the response
            if let userDictionary = response.resultDictionary?.value(forKeyPath: "user") {
                let user: User = ModelMapper<User>.map(userDictionary as! [String : AnyObject])!
                user.accessToken = self.activeUser.accessToken
                user.unReadCount = self.activeUser.unReadCount
                user.flagBankDetails = user.profileStatus
                self.activeUser = user
                self.saveActiveUser()
                completion(true, nil)
            } else {
                completion(true, nil)
            }
            
        } else {
            completion(false, response.responseError)
        }
    }
    
    
    /**
     Method used to handle phone number api response
     
     - parameter response:   api response
     - parameter completion: completion handler
     */
    
    func handlePhoneNumberResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response)")
        
        if response.success {
            // parse the response
            if let userOTP = response.resultDictionary?.value(forKey: "otp") {
                LogManager.logDebug((userOTP as AnyObject).stringValue)
                
                
                UserManager.sharedManager().activeUser.otp = (userOTP as AnyObject).stringValue as String
                UserManager.sharedManager().updateActiveUser()
                
                completion(true, nil)
            }
            else
            {
                completion(false, response.responseError)
            }
        }
        else
        {
            completion(false, response.responseError)
        }
    }
    
    
    func performUrlRequest(_ urlString: String, params: [String: AnyObject], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: urlString, params: params) { (response) -> Void in
            self.handleSignInSignUpResponse(response, completion: completion)
        }
    }
    
    
    // MARK: User Sign Up
    func registerWithEmail(_ email: String, password: String, roleType: String, deviceInfo:[String : String], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        var params : [String:String] = [:]
        params = ["email": email, "password": password, "roleType": roleType]
        params = params.union(deviceInfo)
        performUrlRequest(Constants.APIServiceMethods.sigupAPI, params: params as [String : AnyObject], completion: completion)
    }
    
    
    // MARK: Check Email Alredy Registered
    func checkEmailAlreadyRegistered(_ email: String, roleType: String, deviceInfo:[String : String], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        var params : [String:String] = [:]
        params = ["email": email, "roleType": roleType]
        params = params.union(deviceInfo)
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.checkEmailAPI, params: params as [String : AnyObject]) { (response) -> Void in
            self.handleCheckEmailResponse(response, completion: completion)
        
        }
    }
    
    
    // MARK: Login via phone number
    func performPhoneLogin(_ mobileNumber : String, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let params = ["mobile" : mobileNumber]
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.otpLoginAPI, params: params as [String : AnyObject]?) { (response) in
            
            self.handlePhoneNumberResponse(response, completion: completion)
        }
    }
    
    func performOtpVerify(_ mobileNumber : String,otp : String, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        let parameters = ["mobile": mobileNumber , "otp" : otp]
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.otpLoginVerifyAPI, params: parameters as [String : AnyObject]?) { (response) in
            
            handleApiResponse(response, completion: completion)
        }
        
    }
    
    // MARK: Login via phone number
    func updateProfile(_ params: [String: AnyObject], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        //let finalParams = addAdditionalParameters(params)
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.updateProfileAPI, params: params) { (response) in
            
            self.handleUpdateProfileResponse(response, completion: completion)
        }
    }
    
    
    // MARK: Upload user profile photo
    func addProfileImage(_ profileImage: UIImage, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        var fileParams = [String: AnyObject]()
        fileParams["key"] = "profileImage" as AnyObject?
        fileParams["fileName"] = "userImage.jpg" as AnyObject?
        fileParams["value"] = UIImageJPEGRepresentation(profileImage, 0.2) as AnyObject?
        fileParams["contentType"] = "image/jpeg" as AnyObject?
        
        var postParam = [String: String]()
        postParam["verificationToken"] = self.varificationToken
        
        let request: NSMutableURLRequest = NSMutableURLRequest(url: URL(string: Constants.APIServiceMethods.addProfileImage)!)
        //        request.setMultipartFormData(nil, fileFields: [fileParams, secondParam])
        request.setMultipartFormData(postParam, fileFields: [fileParams])
        RequestManager.sharedManager().performRequest(request, userInfo: nil) { (response) -> Void in
            
            self.handleAddProfileImageResponse(response, completion: completion)
        }
    }
    
    func handleAddProfileImageResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response)")
        
        if response.success {
            // parse the response
            LogManager.logDebug(response.resultDictionary?.description)
            completion(true, nil)
        }
        else
        {
            completion(false, response.responseError)
        }
    }
    
    func handleHireUserProfileResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
          if response.success {
            
//            if let accessToken = response.resultDictionary?.value(forKeyPath: "accessToken") {
            
                LogManager.logDebug("\(response.resultDictionary)")
                if let userDictionary = response.resultDictionary?.value(forKeyPath: "user") {
                    let user: User = ModelMapper<User>.map(userDictionary as! [String : AnyObject])!
                    user.accessToken = self.activeUser.accessToken
                    user.unReadCount = self.activeUser.unReadCount
                    user.flagBankDetails = user.profileStatus
                    self.activeUser = user
                    self.saveActiveUser()
                    completion(true, nil)
                } else {
                    completion(false, response.responseError)
                }
            
            
           }
          else
         {
            completion(false, response.responseError)
         }
    }
    
    // MARK: Upload user profile photo
    func updateProfileImage(_ profileImage: UIImage, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let url = URL(string: Constants.APIServiceMethods.updateProfileImage)
        let request  = NSMutableURLRequest.requestWithURL(url!, method: .POST, jsonDictionary: nil)
        let boundary = "Boundary-\(UUID().uuidString)"
        request.setValue("multipart/form-data; boundary=\(boundary)", forHTTPHeaderField: "Content-Type")
        let image_data = UIImagePNGRepresentation(profileImage)
        if(image_data == nil)
        {
            return
        }
        let body = NSMutableData()
        let fname = "test.png"
        let mimetype = "image/png"
        
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Disposition:form-data; name=\"test\"\r\n\r\n".data(using: String.Encoding.utf8)!)
        body.append("hi\r\n".data(using: String.Encoding.utf8)!)
        
        body.append("--\(boundary)\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Disposition:form-data; name=\"profileImage\"; filename=\"\(fname)\"\r\n".data(using: String.Encoding.utf8)!)
        body.append("Content-Type: \(mimetype)\r\n\r\n".data(using: String.Encoding.utf8)!)
        body.append(image_data!)
        body.append("\r\n".data(using: String.Encoding.utf8)!)
        
        body.append("--\(boundary)--\r\n".data(using: String.Encoding.utf8)!)
        
        request.httpBody = body as Data
        request.addValue(accessToken()!, forHTTPHeaderField: "accessToken")
        request.addValue(deviceId(), forHTTPHeaderField: "deviceId")
        LogManager.logDebug(request.allHTTPHeaderFields?.description)
        
        RequestManager.sharedManager().performRequest(request, userInfo: nil) { (response) -> Void in
            
            self.handleUpdateProfileImageResponse(response, completion: completion)
        }
    }
    
    //get chat history
    
    func getChatHistory(_ params: Dictionary<String,String>, completion: @escaping (_ response: Response,_ success: Bool, _ error: NSError?) -> (Void)) {
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET, urlString: Constants.APIServiceMethods.getChatHistoryAPI, params: params as [String : AnyObject]?) { (response) in
            
            self.handleGetChatHistoryResponse(response, completion: completion)
        }
        
        
    }
    
    // upload chat data
    
    func uploadChatData(_ params: Dictionary<String,String>, completion: @escaping (_ response: Response,_ success: Bool, _ error: NSError?) -> (Void)) {
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.uploadChatDataAPI, params: params as [String : AnyObject]?) { (response) in
            
            if response.success {
                // parse the response
                
                completion(response,true, nil)
                
                
            } else {
                
                completion(response,false, response.responseError)
            }
        }
        
        
    }
    
    
    func handleGetChatHistoryResponse(_ response: Response, completion: (_ response: Response,_ success: Bool, _ error: NSError?) -> (Void)) {
        LogManager.logDebug("response = \(response)")
        
        if response.success {
            // parse the response
            if let _ = response.resultDictionary?.value(forKeyPath: "list") {
                
                completion(response,true, nil)
                
            } else {
                
                completion(response,true, nil)
                
            }
            
        } else {
            
            completion(response,false, response.responseError)
        }
    }

    // MARK: Login using email
    
    func performLogin(_ email:String, password : String , roleType : String,deviceInfo:[String : String], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        var params = ["email" : email, "password" : password, "roleType" : roleType]
        params = params.union(deviceInfo)
        
        performUrlRequest(Constants.APIServiceMethods.loginAPI, params: params as [String : AnyObject], completion: completion)
    }
    
    func performGoogleLogin(_ name : String,email:String, googleId : String,roleType : String,profileImage : String,googleIdToken : String,deviceInfo:[String : String], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        
        var params : [String:String] = [:]
        
        params = ["name" : name , "email" : email , "googleId" : googleId , "roleType" : roleType , "profileImage" :profileImage , "googleIdToken" : googleIdToken]
        
        params = params.union(deviceInfo)
        
        var urlType = ""
        if(UserManager.sharedManager().userType == .userTypeSeeker)
        {
            urlType = Constants.APIServiceMethods.socialLoginGoogleSeeker
        }
        else
        {
            urlType = Constants.APIServiceMethods.socialLoginGoogleProvider
            
        }
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: urlType, params: params as [String : AnyObject]?) { (response) -> Void in
            
            self.handleSignInSignUpResponse(response, completion: completion)
        }
    }
    
    func performLinkedInLogin(_ name : String,email:String, linkedId : String,roleType : String,profileImage : String,authToken : String,deviceInfo:[String : String], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        
        var params : [String:String] = [:]
        
        params = ["name" : name , "email" : email , "linkedinId" : linkedId , "roleType" : roleType , "profileImage" :profileImage , "linkedinIdToken" : authToken]
        
        params = params.union(deviceInfo)
        
        var urlType = ""
        if(UserManager.sharedManager().userType == .userTypeSeeker)
        {
            urlType = Constants.APIServiceMethods.socialLoginLinkedInSeeker
        }
        else
        {
            urlType = Constants.APIServiceMethods.socialLoginLinkedInProvider
            
        }
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: urlType, params: params as [String : AnyObject]?) { (response) -> Void in
            
            self.handleSignInSignUpResponse(response, completion: completion)
        }
    }
    
    
    func performTwitterLogin(_ name : String,email:String, twitterId : String,roleType : String,profileImage : String,twitterIdToken : String,deviceInfo:[String : String], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        
        var params : [String:String] = [:]
        
        params = ["name" : name , "email" : email , "twitterId" : twitterId , "roleType" : roleType , "profileImage" :profileImage , "twitterIdToken" : twitterIdToken]
        
        params = params.union(deviceInfo)
        
        var urlType = ""
        if(UserManager.sharedManager().userType == .userTypeSeeker)
        {
            urlType = Constants.APIServiceMethods.socialLoginTwitterSeeker
        }
        else
        {
            urlType = Constants.APIServiceMethods.socialLoginTwitterProvider
            
        }
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: urlType, params: params as [String : AnyObject]?) { (response) -> Void in
            
            self.handleSignInSignUpResponse(response, completion: completion)
        }
    }
    
    // MARK: Reset user password
    
    func resetPassword(_ email : String,roleType : String, completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let params = ["email" : email, "roleType" : roleType]
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.resetPasswordAPI, params: params as [String : AnyObject]?) { (response) -> Void in
            
            handleApiResponse(response, completion: completion)
        }
    }
    
    
    
    // MARK: Logout
    func performLogout(_ completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.logoutAPI, params: nil) { (response) -> Void in
            
            handleApiResponse(response, completion: completion)
        }
    }
    
    func performDelete(_ completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.DELETE, urlString: Constants.APIServiceMethods.deleteAPI, params: nil) { (response) -> Void in
            
            handleApiResponse(response, completion: completion)
        }
    }
    
    func hireUserProfile(_ name : String,dateOfBirth:String, phonenumber : String,roleType : String,bio: String ,deviceInfo:[String : String], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let param = ["name": name,"phone": phonenumber,"roleType":roleType,"dob":dateOfBirth,"biography": bio]
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.sendHireProfileInfo,params: param as [String : AnyObject]?) { (response) in
                self.handleHireUserProfileResponse(response, completion: completion)
            }
    }
    
    func updateHireUserProfile(_ param: [String: Any], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.sendHireProfileInfo,params: param as [String : AnyObject]?) { (response) in
            self.handleHireUserProfileResponse(response, completion: completion)
        }
    }
    
    func workUserProfile(_ name : String,dateOfBirth:String, phonenumber : String,roleType : String,bio: String,country: NSNumber,city:NSNumber ,deviceInfo:[String : String], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
         let param = ["name": name,"phone": phonenumber,"roleType":roleType,"dob":dateOfBirth,"biography": bio,"permanent_country_id": country,"permanent_city_id":city] as [String : Any]
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.sendWorkProfileInfo,params: param as [String : AnyObject]?) { (response) in
            self.handleHireUserProfileResponse(response, completion: completion)
        }
    }
    
    func updateWorkUserProfile(_ param: [String: Any], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        let param = param
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.sendWorkProfileInfo,params: param as [String : AnyObject]?) { (response) in
            self.handleHireUserProfileResponse(response, completion: completion)
        }
    }
    
    func sendReport(_ viewType:Int, content : String, serviceRequestId : String , completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        if viewType == Constants.kViewTypeContactUs {
            var params = ["content" : content]
            params = params.union(deviceInfo())
            performContactUsUrlRequest(Constants.APIServiceMethods.contactUsAPI, params: params as [String : AnyObject], completion: completion)
        }else{
            var params = ["comment" : content, "serviceRequestId" : serviceRequestId]
            params = params.union(deviceInfo())
            performContactUsUrlRequest(Constants.APIServiceMethods.reportUsAPI, params: params as [String : AnyObject], completion: completion)
        }
    }
    
    func sendProfileVerificationRequest(_ params: [String: AnyObject] , completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        print(params)
        performContactUsUrlRequest(Constants.APIServiceMethods.profileReqestAPI, params: params as [String : AnyObject], completion: completion)
    }
    
    func performContactUsUrlRequest(_ urlString: String, params: [String: AnyObject], completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: urlString, params: params) { (response) -> Void in
            handleApiResponse(response, completion: completion)
        }
    }
    
    //MARK: Get Logged In User Detail
    func  userDetailStanger(stangerUserId : Int,completionStanger: @escaping (_ success: Bool, _ error: NSError?, _ userDetail: User?) -> (Void)) {
        
        let param = ["userId": stangerUserId]
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.userDetailAPI, params:param as [String : AnyObject]? ) { (response) -> Void in
            
            self.handleStangerUserDetailResponse(response, completionStanger: completionStanger)
        }
    }
    
    func handleStangerUserDetailResponse(_ response: Response, completionStanger: (_ success: Bool, _ error: NSError?, _ userDetail: User?) -> (Void)) {
        LogManager.logDebug("response = \(response)")
        
        if response.success {
            // parse the response
            LogManager.logDebug("\(response.resultDictionary)")
            if let userDictionary = response.resultDictionary?.value(forKeyPath: "userDetail") {
                let user: User = ModelMapper<User>.map(userDictionary as! [String : AnyObject])!
                user.accessToken = self.activeUser.accessToken
                user.flagBankDetails = user.profileStatus
                user.unReadCount = self.activeUser.unReadCount
                completionStanger(true, nil,user)

            }else{
                completionStanger(false, nil,nil)
            }
            

        }else{
            completionStanger(false, nil,nil)
        }

    }
    //MARK: Get Logged In User Detail
    func  userDetail(completion: @escaping (_ success: Bool, _ error: NSError?, _ userCategories: [AnyObject]?, _ userTags : [AnyObject]?) -> (Void)) {
        RequestManager.sharedManager().performHTTPActionWithMethod(.POST, urlString: Constants.APIServiceMethods.userDetailAPI, params:nil ) { (response) -> Void in
            
            self.handleUserDetailResponse(response, completion: completion)
        }
    }
    
    func handleUserDetailResponse(_ response: Response, completion: (_ success: Bool, _ error: NSError?, _ userCategories: [AnyObject]?, _ userTags : [AnyObject]? ) -> (Void)) {
        LogManager.logDebug("response = \(response)")
        
        if response.success {
            // parse the response
            LogManager.logDebug("\(response.resultDictionary)")
            var categories = [UserCategory]()
            var tags = [UserTag]()
            if let userDictionary = response.resultDictionary?.value(forKeyPath: "userDetail") {
                let user: User = ModelMapper<User>.map(userDictionary as! [String : AnyObject])!
                user.accessToken = self.activeUser.accessToken
                user.flagBankDetails = user.profileStatus
                user.unReadCount = self.activeUser.unReadCount
                self.activeUser = user
                self.saveActiveUser()
                
            }
            if let _ = response.resultDictionary?.value(forKeyPath: "userCategories") {
              for serviceDict in response.resultDictionary?.value(forKeyPath: "userCategories") as! [AnyObject] {
               let service: UserCategory   = ModelMapper<UserCategory>.map(serviceDict as! [String : AnyObject])!
                
                categories.append(service)
                
                }
            }
            if let _ = response.resultDictionary?.value(forKeyPath: "userTags") {
                
                for serviceDict in response.resultDictionary?.value(forKeyPath: "userTags") as! [AnyObject] {
                    let service: UserTag   = ModelMapper<UserTag>.map(serviceDict as! [String : AnyObject])!
                    
                    tags.append(service)
                    
                }
            }
            completion(true, nil,categories,tags)
//            else {
//                completion(false, response.responseError)
//            }
        }
        else {
            completion(false, response.responseError,nil,nil)
        }
    }
    
    
    //MARK: BID Job API
    func getUnreadNotificationCount(completion: @escaping (_ success: Bool, _ error: NSError?) -> (Void)) {
        
        RequestManager.sharedManager().performHTTPActionWithMethod(.GET, urlString: Constants.APIServiceMethods.unreadNotificationCount, params: deviceInfo() as [String : Any]? as [String : AnyObject]?) { (response) in
            self.handleUnreadNotificationCountRequest(response, completion: completion)
        }
    }
    
    func handleUnreadNotificationCountRequest(_ response: Response, completion: (_ success: Bool, _ error: NSError?) -> (Void)) {
        if response.success {
            LogManager.logDebug("\(response.resultDictionary)")
            if let _ = response.resultDictionary?.value(forKeyPath: "message") {
                
                if let newCount = response.resultDictionary?.value(forKeyPath: "unReadCount"){
                
//                    let count = "\((response.resultDictionary?.value(forKeyPath: "unReadCount"))!)"
                    let count = "\(newCount)"
                    self.activeUser.unReadCount = NSNumber(value: Int(count)!)
                    self.saveActiveUser()
                    if Int(count)! > 99 {
                        NotificationCenter.default.post(name: Constants.NOTIFICATION_UNREAD_COUNT, object: self, userInfo: ["unreadCount":"99+"])
                    }else{
                        NotificationCenter.default.post(name: Constants.NOTIFICATION_UNREAD_COUNT, object: self, userInfo: ["unreadCount":"\((self.activeUser.unReadCount!))"])
                    }
                
                }else{
                
                    let count = "0"
                    self.activeUser.unReadCount = NSNumber(value: Int(count)!)
                    self.saveActiveUser()
                    if Int(count)! > 99 {
                        NotificationCenter.default.post(name: Constants.NOTIFICATION_UNREAD_COUNT, object: self, userInfo: ["unreadCount":"99+"])
                    }else{
                        NotificationCenter.default.post(name: Constants.NOTIFICATION_UNREAD_COUNT, object: self, userInfo: ["unreadCount":"\((self.activeUser.unReadCount!))"])
                    }
                
                }

                completion(true, nil)
            } else {
                completion(false, response.responseError)
            }
        }
        else
        {
            completion(false, response.responseError)
        }
    }
    
    
    
}
